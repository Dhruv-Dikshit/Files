// Header features: word-by-word placement, Convert Captions panel, "..." menu.
const WBW = {
  model(styleId, word) {
    const st = TF.clone(App.style(styleId));
    st.big = TF.clone(st.small); // the style's small-word look
    const blocks = TF.layout([word], 1, st, { aspect: App.aspect(), center: [0.5, 0.3], scale: 1.6, look: 'style' });
    const anim = TF.clone(App.style(styleId).anim);
    [anim.in, anim.out].forEach((s) => { if (s.slide) { s.dir = 'right'; s.dist = 0.03; } s.frames = Math.min(s.frames, 8); });
    return { styleId, template: 1, look: 'style', blocks, anim };
  },
  clean(words, remove) {
    return words.map((w) => Object.assign({}, w, { word: remove ? String(w.word).replace(/[,.!?;:…"“”()]/g, '') : String(w.word) })).filter((w) => w.word.trim());
  },
  // the look of a sample block (from the Workspace canvas) applied to a word model
  LOOK: ['font', 'fontStyle', 'color', 'glow', 'glowS', 'glowSp', 'glowO', 'tracking', 'opacity', 'case', 'fx', 'size'],
  fromSample(model, sample, word) {
    const m = TF.clone(model), sb = sample.blocks[0], b = m.blocks[0];
    WBW.LOOK.forEach((k) => { if (sb[k] === undefined) delete b[k]; else b[k] = TF.clone(sb[k]); });
    b.text = word; b.x = sb.x; b.y = sb.y;
    m.anim = TF.clone(sample.anim);
    return m;
  },
  async place(words, o) {
    const ws = WBW.clean(words, o.remove !== false);
    if (!ws.length) { App.msg('No words to place.', 'err'); return { ok: false }; }
    const mk = (w) => (o.sample ? WBW.fromSample(WBW.model(o.styleId, w), o.sample, w) : WBW.model(o.styleId, w));
    const items = ws.map((w, i) => ({ start: w.start, end: Math.max(ws[i + 1] ? ws[i + 1].start : w.end, w.start + 6), model: mk(w.word) }));
    return App.call('placeCaptions', { items, track: o.track || 2 });
  },
};

// One Text+ per word: word k goes on its own track (base + k), placed where the template puts it,
// starts when it is spoken and ends with the caption. The layers stack into the full caption.
// Resolve inserts on the destination track, which TitleFlow moves with Option+track number (V1-V8).
const WL = {
  starts(g, n) {
    const ts = g.ts || [];
    if (ts.length === n) return ts;
    const out = []; const a = g.start, b = Math.max(g.end, a + n);
    for (let k = 0; k < n; k++) out.push(Math.round(a + ((b - a) * k) / n));
    return out;
  },
  MAX_TRACK: 8,
  items(model, starts, end, baseTrack) {
    return model.blocks.map((b, k) => {
      const st = starts[Math.min(k, starts.length - 1)];
      const blk = Object.assign({}, b); delete blk.delay;
      return { start: st, end: Math.max(end, st + 6), track: Math.min(baseTrack + k, WL.MAX_TRACK), model: { styleId: model.styleId, template: model.template, look: model.look, blocks: [blk], anim: TF.clone(model.anim) } };
    });
  },
  // matchPrev: true (all items) or the number of leading items whose entry should follow the previous title's exit
  place(items, matchPrev) { return App.call('placeWords', { items, matchPrev: matchPrev || false }); },
};

(function header() {
  const panel = $('#convert-panel');
  let words = [];
  window.tf.onProgress((d) => App.emit('progress', d));

  function fillStyles() {
    const sel = $('#cv-style'); const cur = sel.value;
    sel.innerHTML = App.styles().map((s) => `<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
    if (cur) sel.value = cur; else sel.value = 'em-bold-yellow';
    $('#cv-look').innerHTML = '<option value="">Look from style…</option>' + App.styles().map((s) => `<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
  }
  const showSample = () => Workspace.enterSample(WBW.model($('#cv-style').value, 'sample'));
  $('#cv-style').addEventListener('change', () => { if (!panel.hidden) showSample(); });
  $('#cv-look').addEventListener('change', (e) => {
    const id = e.target.value; if (!id) return;
    const cur = Workspace.sampleModel(); if (!cur) return;
    const look = WBW.model(id, 'sample'), b = cur.blocks[0], lb = look.blocks[0];
    WBW.LOOK.forEach((k) => { if (lb[k] === undefined) delete b[k]; else b[k] = TF.clone(lb[k]); });
    cur.anim = look.anim; Workspace.enterSample(cur); e.target.value = '';
    App.msg('Sample word now uses the look of ' + App.style(id).name + '.', 'ok');
  });
  const shut = () => { panel.hidden = true; $('#convert').classList.remove('on'); Workspace.exitSample(); };
  async function open() {
    App.showTab('workspace');
    fillStyles(); panel.hidden = false; $('#convert').classList.add('on');
    showSample();
    const r = await App.call('readCaptions', { useInOut: !!(App.status && App.status.inOut) });
    words = r.ok ? r.words : [];
    const io = App.status && App.status.inOut;
    $('#cv-go').textContent = words.length ? `Convert ${words.length} · ${io ? 'In/Out' : 'All'}` : 'No subtitles';
    $('#cv-track').innerHTML = `<option>Subtitle 1 · ${words.length}</option>`;
    $('#cv-go').disabled = !words.length;
    if (r.ok && !r.hasSubtitles) App.msg('No subtitle track. In Resolve: Timeline > Create Subtitles from Audio (max 1 character per line), or use Auto > Generate from audio.', 'err');
  }
  $('#convert').addEventListener('click', () => (panel.hidden ? open() : shut()));
  $('#cv-x').addEventListener('click', shut);
  $('#cv-go').addEventListener('click', async () => {
    $('#cv-go').disabled = true; $('#cv-form').hidden = true; $('#cv-prog').hidden = false; $('#cv-bar').style.width = '0%'; $('#cv-pt').textContent = `Converting 0 / ${words.length} · subtitles`;
    const r = await WBW.place(words, { styleId: $('#cv-style').value, remove: $('#cv-punct').checked, track: Math.max(1, parseInt($('#cv-vt').value, 10) || 2), sample: Workspace.sampleModel() });
    $('#cv-prog').hidden = true; $('#cv-form').hidden = false; $('#cv-go').disabled = false;
    if (r && r.ok) App.msg(`Converted ${r.done - r.failed}/${words.length}${r.cancelled ? ' (cancelled)' : ''}${r.failed ? `, ${r.failed} failed (see Log)` : ''}.${r.warning ? ' ' + r.warning : ''}`, r.failed ? 'err' : 'ok');
  });
  App.on('progress', (d) => { if ($('#cv-prog').hidden) return; $('#cv-bar').style.width = (d.i / d.n) * 100 + '%'; $('#cv-pt').textContent = `Converting ${d.i} / ${d.n} · subtitles`; });
  $('#cv-cancel').addEventListener('click', () => App.call('cancel'));

  // minimize: shrink the window to the header for playback, click again to restore
  $('#mini').addEventListener('click', () => {
    const on = !document.body.classList.contains('mini');
    document.body.classList.toggle('mini', on);
    $('#mini').textContent = on ? '▢' : '—'; $('#mini').title = on ? 'Restore the panel' : 'Minimize the panel for playback';
    App.call('compact', on);
  });

  const pop = $('#menupop');
  $('#menu').addEventListener('click', (e) => { e.stopPropagation(); pop.hidden = !pop.hidden; });
  document.addEventListener('click', () => { pop.hidden = true; });
  pop.addEventListener('click', (e) => e.stopPropagation());
  pop.addEventListener('click', (e) => {
    const m = e.target.dataset.m; if (!m) return;
    if (m === 'bug') { $('#logpanel').hidden = false; $('#logbtn').textContent = 'Log ▾'; $('#logbtn').dispatchEvent(new Event('refreshlog')); window.tf.getLog().then((r) => { $('#logtext').value = (r && r.text) || ''; }); App.msg('Press Copy log and paste it with your bug report.'); }
    else if (m === 'probe') { App.msg('Running diagnostics on the clip under the playhead…'); App.call('probe').then((r) => { if (r.ok) { $('#logpanel').hidden = false; window.tf.getLog().then((l) => { $('#logtext').value = (l && l.text) || ''; $('#logtext').scrollTop = 1e9; }); App.msg('Diagnostics done. Press Copy log and paste it to Claude.', 'ok'); } }); }
    else if (m === 'update') App.msg('TitleFlow 0.12.0. Updates are manual for now: replace the plugin folder with the new version.');
    else if (m === 'cache') App.msg('Many Text+ titles are heavy. If playback stutters, turn on Playback > Render Cache > Smart (or User) in Resolve.');
    else if (m === 'reset') { App.custom.length = 0; App.saveCustom(); location.reload(); }
  });
  App.on('show:titles', fillStyles);
})();
