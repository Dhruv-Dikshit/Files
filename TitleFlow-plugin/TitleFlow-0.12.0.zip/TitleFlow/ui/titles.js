// TITLES tab: pick a style, edit words/layout, insert at playhead or In/Out.
const Titles = (() => {
  const POS = { top: [0.5, 0.78], middle: [0.5, 0.5], bottom: [0.5, 0.22] };
  const T = {
    mode: 'playhead', wordsText: '', userEdited: false, search: '', styleId: null,
    tpl: 1, look: 'style', scale: 1, animMode: 'style', anim: null, pos: 'middle',
    track: 2, seconds: 3, match: true, lastIO: '', anPlay: null, insAs: 'one', custom: null, wo: {}, selW: -1, ioWords: [], filter: true, hint: true,
  };
  const root = $('#pane-titles');
  let ae = null;

  root.innerHTML = `
  <div id="t-grid">
    <div class="bar nowrap">
      <div class="seg" id="t-mode"><button data-v="playhead">Playhead</button><button data-v="inout" id="t-inout">In/Out</button></div>
      <label class="search" id="t-sbtn" title="Search styles">${ICONS.search}<input id="t-search" placeholder="Search"></label>
      <button class="btn" id="t-import">⤓ Import…</button>
      <button class="btn" id="t-addtl">+ Add from timeline</button>
    </div>
    <div class="infobar" id="t-info"></div>
    <div class="hintbar" id="t-hint">Click a style — the sample word gets its look. Hover a card to see it animate. <button class="icon" id="t-hint-x">×</button></div>
    <div class="cards" id="t-cards"></div>
    <div class="foot-count" id="t-count"></div>
  </div>

  <div id="t-editor" hidden>
    <div class="ed-head"><b id="t-ed-name"></b><span class="mute grow" id="t-ed-sub"></span><button class="btn" id="t-back">Titles</button><button class="icon" id="t-close">×</button></div>
    <div class="frow"><label>Words</label><input id="t-words" class="grow" placeholder="Type the words for the title"></div>
    <div class="frow"><label>Insert as</label><div class="seg" id="t-insas"><button data-v="one">One caption</button><button data-v="word">Word by word</button></div></div>
    <div class="hint" id="t-insas-h"></div>
    <label class="flbl">Style</label>
    <button class="stylecard" id="t-stylecard"><span class="thumb" id="t-thumb"></span><b id="t-sc-name"></b><span class="mute">Change ▾</span></button>
    <div class="frow"><label>Animation</label><div class="seg" id="t-animmode"><button data-v="style">From style</button><button data-v="custom">Customize</button><button data-v="off">Off</button></div></div>
    <div id="t-ae" hidden></div>
    <label class="flbl">Preview</label>
    <div class="preview-box"><div id="t-stage-slot"></div><button class="icon play-ov" id="t-play" title="Play">${ICONS.play}</button></div>
    <div class="grip"><i></i></div>
    <div class="seg tplbig" id="t-tpl"><button data-v="1">${ICONS.t1}<span>Template 1</span></button><button data-v="2">${ICONS.t2}<span>Template 2</span></button><button data-v="3">${ICONS.t3}<span>Template 3</span></button></div>
    <div class="frow"><label>Size · all</label><input type="range" id="t-size" min="50" max="160" value="100"><span class="val" id="t-size-v"></span></div>
    <div class="frow"><label>Look · all</label><div class="seg dashed" id="t-look"><button data-v="standard">Standard</button><button data-v="style">Style</button></div></div>
    <details class="fold"><summary>Lines &amp; word styling</summary>
      <div class="lines" id="t-lines"></div>
      <div class="wsel" id="t-wsel"></div>
      <div class="hint">Drag a word to another line. Click a word to style it. Shift-click makes it the main word.</div>
    </details>
    <div class="frow"><label>Position</label><div class="seg" id="t-pos"><button data-v="top">Top</button><button data-v="middle">Middle</button><button data-v="bottom">Bottom</button></div></div>
    <div class="frow" id="t-len-row"><label>Length</label><input type="range" id="t-len" min="1" max="7" step="0.1"><span class="val" id="t-len-v"></span></div>
    <div class="frow"><label>Track</label><input type="number" id="t-track" class="num" min="1" max="20" title="First video track: word 1 goes here, word 2 on the next track, and so on (up to V8). Other tracks are locked while inserting."><span class="grow"></span></div>
    <button class="primary" id="t-insert">Insert title</button>
  </div>`;
  const curStyle = () => App.style(T.styleId);
  const words = () => TF.wordsFrom(T.wordsText, true);

  function buildModel(opts) {
    opts = opts || {};
    const style = curStyle(), ws = words(), asp = App.aspect();
    const lo = { look: T.look, scale: T.scale, aspect: asp, center: POS[T.pos] };
    let blocks;
    if (T.custom && T.custom.n === ws.length) blocks = TF.explode(TF.layoutLines(ws, T.custom.lines, T.custom.roles, style, lo), asp);
    else blocks = TF.explode(TF.layout(ws, T.tpl, style, lo), asp);
    if (blocks.every((b) => b.wi != null)) blocks.sort((a, c) => a.wi - c.wi); else blocks.forEach((b, i) => { b.wi = i; });
    blocks.forEach((b) => {
      const o = T.wo[b.wi]; if (!o) return;
      if (o.role) { const sv = style[o.role]; b.role = o.role; b.size = (o.role === 'big' ? style.big.size : style.small.size) * T.scale; b.font = sv.font; b.fontStyle = sv.fontStyle; if (T.look !== 'standard') b.glow = !!sv.glow; }
      if (o.color) b.color = o.color.slice();
    });
    const anim = T.animMode === 'off' ? TF.noAnim() : T.animMode === 'custom' && T.anim ? TF.clone(T.anim) : TF.clone(style.anim);
    return { styleId: style.id, template: T.tpl, look: T.look, blocks, anim };
  }

  // ---------- lines editor (drag words between lines, per-word style) ----------
  const hex = (c) => '#' + c.map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
  function curLines() {
    const ws = words();
    if (T.custom && T.custom.n === ws.length) return T.custom;
    const l = TF.linesOf(ws, T.tpl, curStyle(), App.aspect());
    return { n: ws.length, lines: l.lines, roles: l.roles };
  }
  function setMain(wi) {
    const n = words().length, pre = [], post = [];
    for (let k = 0; k < n; k++) { if (k < wi) pre.push(k); else if (k > wi) post.push(k); }
    const lines = [], roles = [];
    if (pre.length) { lines.push(pre); roles.push('small'); }
    lines.push([wi]); roles.push('big');
    if (post.length) { lines.push(post); roles.push('small'); }
    T.custom = { n, lines, roles }; T.selW = wi;
  }
  function renderLines() {
    const box = $('#t-lines'); if (!box) return;
    const ws = words(); box.innerHTML = '';
    if (!ws.length) return;
    const c = curLines();
    const drop = (rowIdx) => (e) => {
      e.preventDefault(); const wi = +e.dataTransfer.getData('text/plain'); if (isNaN(wi)) return;
      const lines = c.lines.map((l) => l.filter((x) => x !== wi)), roles = c.roles.slice();
      if (rowIdx >= lines.length) { lines.push([wi]); roles.push('small'); } else lines[rowIdx].push(wi);
      lines[rowIdx >= lines.length ? lines.length - 1 : rowIdx].sort((a, b) => a - b);
      for (let k = lines.length - 1; k >= 0; k--) if (!lines[k].length) { lines.splice(k, 1); roles.splice(k, 1); }
      T.custom = { n: ws.length, lines, roles }; renderLines(); refreshStage();
    };
    const mkRow = (l, i) => {
      const row = document.createElement('div'); row.className = 'lrow';
      const tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = i < c.lines.length ? (c.roles[i] === 'big' ? 'BIG' : 'small') : '+ line';
      tag.style.cursor = i < c.lines.length ? 'pointer' : 'default';
      if (i < c.lines.length) tag.addEventListener('click', () => { const r = c.roles.slice(); r[i] = r[i] === 'big' ? 'small' : 'big'; T.custom = { n: ws.length, lines: c.lines, roles: r }; renderLines(); refreshStage(); });
      row.appendChild(tag);
      (l || []).forEach((wi) => {
        const ch = document.createElement('span'); ch.className = 'wchip' + (T.selW === wi ? ' sel' : ''); ch.textContent = ws[wi]; ch.draggable = true;
        ch.addEventListener('dragstart', (e) => e.dataTransfer.setData('text/plain', String(wi)));
        ch.addEventListener('click', (e) => { if (e.shiftKey) setMain(wi); T.selW = wi; renderLines(); renderWsel(); refreshStage(); });
        row.appendChild(ch);
      });
      row.addEventListener('dragover', (e) => { e.preventDefault(); row.classList.add('over'); });
      row.addEventListener('dragleave', () => row.classList.remove('over'));
      row.addEventListener('drop', (e) => { row.classList.remove('over'); drop(i)(e); });
      box.appendChild(row);
    };
    c.lines.forEach(mkRow); mkRow([], c.lines.length);
    renderWsel();
  }
  function renderWsel() {
    const el = $('#t-wsel'); if (!el) return;
    const ws = words(), wi = T.selW;
    if (wi < 0 || wi >= ws.length) { el.innerHTML = '<span class="mute">Select a word to style it.</span>'; return; }
    const style = curStyle(); const o = T.wo[wi] || {};
    const col = o.color || (o.role === 'small' ? style.small.color : (curLines().roles[curLines().lines.findIndex((l) => l.includes(wi))] === 'big' ? style.big.color : style.small.color));
    el.innerHTML = `<b>${esc(ws[wi])}</b><input type="color" value="${hex(col)}"><button data-r="big" class="${o.role === 'big' ? 'on' : ''}">Big</button><button data-r="small" class="${o.role === 'small' ? 'on' : ''}">Small</button><button data-r="main">Main word</button><button data-r="clear">Clear</button>`;
    $('input', el).onchange = (e) => { const h = e.target.value; T.wo[wi] = Object.assign(T.wo[wi] || {}, { color: [1, 3, 5].map((k) => parseInt(h.substr(k, 2), 16) / 255) }); refreshStage(); };
    $$('button', el).forEach((b) => b.onclick = () => {
      const r = b.dataset.r;
      if (r === 'clear') delete T.wo[wi]; else if (r === 'main') setMain(wi); else T.wo[wi] = Object.assign(T.wo[wi] || {}, { role: r });
      renderLines(); refreshStage();
    });
  }

  // ---------- grid ----------
  function sampleModel(style) {
    return { styleId: style.id, blocks: TF.layout(['EASY', 'MOTION'], 1, style, { aspect: 16 / 10, scale: 2.6 }), anim: style.anim };
  }
  function blockCount() { return TF.layout(words().length ? words() : ['A', 'B', 'C', 'D'], T.tpl, TF.STYLES[0], { aspect: 1 }).length; }
  function renderCards() {
    const el = $('#t-cards');
    el.innerHTML = '';
    const nBlocks = blockCount();
    const shown = App.styles().filter((s) => (!T.search || (s.name + ' ' + (s.tags || '')).toLowerCase().includes(T.search.toLowerCase())) && !(T.filter && T.mode === 'inout' && s.nb && s.nb !== nBlocks));
    $('#t-count').textContent = shown.length + ' titles';
    shown.forEach((s) => {
      const card = document.createElement('div');
      card.className = 'card' + (s.id === T.styleId ? ' sel' : '');
      const st = document.createElement('div');
      st.className = 'stage sm'; st.style.aspectRatio = '16/10';
      card.appendChild(st);
      const nm = document.createElement('div');
      nm.className = 'cname'; nm.innerHTML = `<span>${esc(s.name)}</span><i>${T.mode === 'inout' ? '×' + nBlocks : (s.nb || nBlocks)}</i>`;
      card.appendChild(nm);
      el.appendChild(card);
      const m = sampleModel(s);
      Preview.render(st, m);
      Preview.hover(card, st, () => m);
      card.addEventListener('click', () => openEditor(s.id));
    });
  }

  async function detect() {
    const info = $('#t-info');
    insLabel();
    info.hidden = T.mode !== 'inout';
    if (T.mode !== 'inout') { info.innerHTML = ''; return; }
    const r = await App.call('readCaptions', { useInOut: true });
    if (!r.ok) { info.textContent = r.error; return; }
    T.ioWords = [];
    if (!r.inOut) { info.innerHTML = '<span class="mute">Set In/Out marks on the timeline (I and O) around the words.</span>'; return; }
    const ws = r.words.map((w) => w.word);
    if (ws.length) {
      T.ioWords = r.words;
      info.innerHTML = `<b>${ws.length} words in In/Out</b> <span class="mute">· ${esc(ws.slice(0, 8).join(' · '))}${ws.length > 8 ? ' …' : ''}</span><label class="toggle right"><input type="checkbox" id="t-filter" ${T.filter ? 'checked' : ''}><span>titles with ${blockCount()} blocks</span></label>`;
      const fb = $('#t-filter'); if (fb) fb.onchange = (e) => { T.filter = e.target.checked; renderCards(); };
      insLabel();
      if (!T.userEdited) { T.wordsText = ws.join(' '); $('#t-words').value = T.wordsText; renderCards(); if (!$('#t-editor').hidden) refreshStage(); }
    } else info.innerHTML = '<span class="mute">No subtitle words inside In/Out. Type the words below, or make captions in the Auto tab.</span>';
  }

  // ---------- editor ----------
  let stage = null;
  function openEditor(id) {
    T.styleId = id;
    T.anim = TF.clone(curStyle().anim);
    $('#t-grid').hidden = true; $('#t-editor').hidden = false;
    $('#t-ed-name').textContent = curStyle().name;
    $('#t-sc-name').textContent = curStyle().name;
    const th = Preview.make('sm'); th.style.aspectRatio = '16/9'; $('#t-thumb').innerHTML = ''; $('#t-thumb').appendChild(th); Preview.render(th, sampleModel(curStyle()));
    edSub();
    if (!stage) { stage = Preview.make('ed'); $('#t-stage-slot').appendChild(stage); }
    App.setAspect(stage);
    T.custom = null; T.wo = {}; T.selW = -1;
    syncControls(); renderLines(); refreshStage();
  }
  function edSub() { const n = words().length; $('#t-ed-sub').textContent = n ? `· ${n} word${n > 1 ? 's' : ''}${T.mode === 'inout' && T.ioWords.length ? ' from In/Out' : ''}` : ''; }
  function closeEditor() { $('#t-editor').hidden = true; $('#t-grid').hidden = false; renderCards(); }
  function refreshStage() {
    if (!stage) return; if (T.anPlay) { T.anPlay.cancel(); T.anPlay = null; }
    Preview.render(stage, buildModel());
    $$('.blk', stage).forEach((el) => { el.style.cursor = 'pointer'; el.addEventListener('click', (e) => { const b = buildModel().blocks[+el.dataset.i]; if (!b) return; if (e.shiftKey) setMain(b.wi); T.selW = b.wi; renderLines(); refreshStage(); }); });
  }

  function syncControls() {
    paintTpl(); paintLook(); paintAnim(); paintPos();
    $('#t-size').value = Math.round(T.scale * 100); sizeLbl();
    $('#t-track').value = T.track;
    $('#t-len').value = T.seconds; lenLbl();
    $('#t-len-row').hidden = T.mode === 'inout';
    $('#t-ae').hidden = T.animMode !== 'custom';
    if (ae) ae.refresh();
  }
  const sizeLbl = slider($('#t-size'), $('#t-size-v'), (v) => Math.round(v) + '%', (v) => { T.scale = v / 100; refreshStage(); });
  const lenLbl = slider($('#t-len'), $('#t-len-v'), (v) => v.toFixed(1) + ' s', (v) => { T.seconds = v; });
  const paintTpl = seg($('#t-tpl'), () => T.tpl, (v) => { T.tpl = +v; T.custom = null; renderLines(); refreshStage(); });
  const paintLook = seg($('#t-look'), () => T.look, (v) => { T.look = v; refreshStage(); });
  const paintAnim = seg($('#t-animmode'), () => T.animMode, (v) => {
    T.animMode = v; if (v === 'custom' && !T.anim) T.anim = TF.clone(curStyle().anim);
    $('#t-ae').hidden = v !== 'custom'; if (ae) ae.refresh(); refreshStage();
  });
  const paintPos = seg($('#t-pos'), () => T.pos, (v) => { T.pos = v; refreshStage(); });
  ae = AnimEditor.mount($('#t-ae'), { get: () => T.anim, set: (a) => { T.anim = a; refreshStage(); } });

  $('#t-track').addEventListener('change', (e) => { T.track = Math.max(1, parseInt(e.target.value, 10) || 2); });
  $('#t-back').addEventListener('click', closeEditor);
  $('#t-close').addEventListener('click', closeEditor);
  $('#t-stylecard').addEventListener('click', closeEditor);
  $('#t-play').addEventListener('click', () => {
    if (T.anPlay) T.anPlay.cancel();
    const g = $('.grp', stage); if (g) T.anPlay = Preview.play(g, buildModel());
  });

  $('#t-insert').addEventListener('click', async () => {
    const btn = $('#t-insert');
    if (T.insAs === 'word' && !T.ioWords.length) { T.insAs = 'one'; T.mode = 'playhead'; }
    if (T.insAs === 'word') {
      btn.disabled = true; App.msg('Placing words…');
      const r = await WBW.place(T.ioWords, { styleId: T.styleId, remove: true, track: T.track });
      btn.disabled = false;
      if (r && r.ok) App.msg(`Placed ${r.done - r.failed}/${T.ioWords.length} words${r.failed ? ', ' + r.failed + ' failed (see Log)' : ''}.${r.warning ? ' ' + r.warning : ''}`, r.failed ? 'err' : 'ok');
      return;
    }
    if (!words().length) return App.msg('Type some words first.', 'err');
    btn.disabled = true; App.msg('Inserting…');
    const st = App.status || {}, fps = st.fps || 30, model = buildModel();
    let start = st.playhead || 0, end = start + Math.round(T.seconds * fps), starts = model.blocks.map(() => start);
    if (T.mode === 'inout' && st.inOut) {
      if (!st.inOut) { btn.disabled = false; return App.msg('Set In/Out marks (I and O) first.', 'err'); }
      start = st.inOut.in; end = st.inOut.out;
      const ws = WBW.clean(T.ioWords, true);
      starts = model.blocks.map((_, k) => (ws.length === model.blocks.length ? ws[k].start : start));
    }
    const items = WL.items(model, starts, end, T.track);
    const r = await WL.place(items, true);
    btn.disabled = false;
    if (r && r.ok) App.msg(`Inserted ${r.done - r.failed}/${items.length} word layers${r.failed ? ', ' + r.failed + ' failed (see Log)' : ''}.${r.warning ? ' ' + r.warning : ''}`, r.failed ? 'err' : 'ok');
  });

  // ---------- grid controls ----------
  $('#t-hint-x').addEventListener('click', () => { $('#t-hint').hidden = true; });
  const paintIns = seg($('#t-insas'), () => T.insAs, (v) => { T.insAs = v; insLabel(); });
  function insLabel() {
    const n = T.ioWords.length;
    $('#t-insert').textContent = T.insAs === 'word' ? `Insert ${n || ''} words`.replace('  ', ' ') : 'Insert title';
    $('#t-insas-h').textContent = T.insAs === 'word'
      ? "Each In/Out word goes on the timeline on its own, in its own time, with the style's small-word look at caption height and a light slide to the right."
      : 'Every word becomes its own Text+ on its own video track (word 1 on the Track below, word 2 on the next, up to V8), stacked as the template lays them out. Each starts when it is spoken (or at the playhead); all leave together.';
    $('#t-len-row').hidden = T.mode === 'inout' || T.insAs === 'word';
  }
  const setMode = (v) => { T.mode = v; T.userEdited = false; $('#t-len-row').hidden = v === 'inout'; detect(); };
  const paintMode = seg($('#t-mode'), () => T.mode, setMode);
  $('#t-words').addEventListener('input', (e) => { T.wordsText = e.target.value; T.userEdited = true; T.custom = null; T.wo = {}; T.selW = -1; renderCards(); renderLines(); refreshStage(); edSub(); });
  $('#t-search').addEventListener('input', (e) => { T.search = e.target.value; renderCards(); });

  const normStyle = (s) => {
    const base = TF.clone(TF.STYLES[1]);
    return Object.assign(base, s, {
      id: s.id || 'custom-' + Date.now() + Math.random().toString(36).slice(2, 5),
      big: Object.assign(base.big, s.big || {}), small: Object.assign(base.small, s.small || {}),
      anim: s.anim || base.anim,
    });
  };
  $('#t-import').addEventListener('click', async () => {
    const r = await App.call('importStyle');
    if (r.ok && r.styles.length) { r.styles.forEach((s) => App.custom.push(normStyle(s))); App.saveCustom(); renderCards(); App.msg(`Imported ${r.styles.length} style(s).`, 'ok'); }
  });
  $('#t-addtl').addEventListener('click', async () => {
    const r = await App.call('titleAtPlayhead');
    if (!r.ok) return;
    if (r.none) return App.msg('No TitleFlow title under the playhead to copy a style from.', 'err');
    App.openGallery(r.model);
  });

  // ---------- Add to gallery dialog ----------
  let galModel = null;
  App.openGallery = (model, sel) => {
    const bl = sel && sel.length ? sel.map((i) => model.blocks[i]).filter(Boolean) : model.blocks;
    galModel = { blocks: bl.length ? bl : model.blocks, anim: model.anim };
    $('#g-info').textContent = galModel.blocks.map((b) => b.text).join(' · ').toUpperCase() + `\n${galModel.blocks.length} blocks · ${galModel.anim.in.frames + galModel.anim.out.frames} frames · ${(App.status && App.status.w) || 1080}×${(App.status && App.status.h) || 1920}`;
    $('#g-name').value = galModel.blocks.map((b) => b.text).join(' ').toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()).slice(0, 28);
    $('#g-style').value = ''; $('#g-tags').value = '';
    $('#gallery-modal').hidden = false;
  };
  $('#g-x').addEventListener('click', () => { $('#gallery-modal').hidden = true; });
  $('#g-save').addEventListener('click', () => {
    if (!galModel) return;
    const bs = galModel.blocks.slice().sort((a, b) => b.size - a.size);
    const big = bs[0], small = bs[bs.length - 1];
    const s = normStyle({
      name: $('#g-name').value.trim() || 'CUSTOM ' + (App.custom.length + 1), upper: false, nb: galModel.blocks.length,
      tags: ($('#g-style').value + ' ' + $('#g-tags').value).trim(),
      big: { font: big.font, fontStyle: big.fontStyle, size: big.size, color: big.color, glow: big.glow },
      small: { font: small.font, fontStyle: small.fontStyle, size: small.size, color: small.color },
      anim: TF.clone(galModel.anim),
    });
    App.custom.push(s); App.saveCustom(); renderCards();
    $('#gallery-modal').hidden = true; App.msg('Saved to the gallery.', 'ok');
  });

  App.on('status', (st) => {
    const io = st.inOut ? st.inOut.in + '-' + st.inOut.out : '';
    if (io !== T.lastIO) {
      T.lastIO = io; T.userEdited = false;
      // new In/Out marks (picked from the transcript) switch the tab to In/Out; clearing them goes back to Playhead
      if (io && T.mode !== 'inout') { setMode('inout'); paintMode(); }
      else if (!io && T.mode === 'inout') { setMode('playhead'); paintMode(); }
      else if (T.mode === 'inout') detect();
    }
    $('#t-inout').textContent = 'In/Out' + (T.mode === 'inout' && T.ioWords.length ? ' · ' + T.ioWords.length : '');
    if (stage) App.setAspect(stage);
  });
  App.on('show:titles', () => { detect(); });

  T.styleId = TF.STYLES[1].id;
  insLabel(); renderCards(); detect();
  return { T, buildModel };
})();
