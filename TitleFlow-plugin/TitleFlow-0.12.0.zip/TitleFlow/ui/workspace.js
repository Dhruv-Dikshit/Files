// WORKSPACE tab: edit the title under the playhead (or every title in In/Out) on a canvas.
// Click a word to style it, Cmd/Ctrl-click for several, drag a box to select a whole caption, Shift-click marks the main word. Every tool acts on the selection.
const Workspace = (() => {
  const W = { mode: 'playhead', uid: null, model: null, sel: [], hist: [], fut: [], tpl: 1, timer: null, busy: false, dirty: false, anPlay: null, ae: null, zoom: 1, video: false, bg: null, parts: [], anims: {}, saved: {}, key: null, len: 3 };
  const root = $('#pane-workspace');
  const FONTS = ['Poppins', 'Montserrat', 'Open Sans', 'Helvetica Neue', 'Arial', 'Impact', 'Georgia', 'Courier New'];
  const WEIGHTS = ['Light', 'Regular', 'Medium', 'Bold', 'ExtraBold', 'Black'];
  const hex = (c) => '#' + c.map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
  const unhex = (h) => [1, 3, 5].map((k) => parseInt(h.substr(k, 2), 16) / 255);

  root.innerHTML = `
  <div class="bar ws-bar">
    <div class="seg" id="w-mode"><button data-v="playhead">Playhead</button><button data-v="inout">In/Out</button></div>
    <div class="seg" id="w-tpl"><button data-v="1" title="Template 1 (Shift-click: also apply its animation)">${ICONS.t1}</button><button data-v="2" title="Template 2 (Shift-click: also apply its animation)">${ICONS.t2}</button><button data-v="3" title="Template 3 (Shift-click: also apply its animation)">${ICONS.t3}</button></div>
    <button class="btn outline" id="w-addtext">+ Text</button>
    <span class="grow"></span>
    <div class="seg ur"><button id="w-undo" title="Undo (Cmd+Z)">${ICONS.undo}</button><button id="w-redo" title="Redo (Shift+Cmd+Z)">${ICONS.redo}</button></div>
  </div>
  <div class="canvas-row">
    <div class="fl fl-tl canvas-bar">
      <button data-a="left" title="Align left">${ICONS.alignL}</button><button data-a="center" title="Align center">${ICONS.alignC}</button><button data-a="right" title="Align right">${ICONS.alignR}</button>
      <button id="w-all" title="Select whole caption (Cmd+A)" hidden>${ICONS.all}</button>
    </div>
    <div class="fl fl-tr">
      <button id="w-video" title="Show the video frame behind the canvas">${ICONS.video}</button>
      <button id="w-reset" title="Reset layout">${ICONS.reset}</button>
      <button id="w-play" title="Play animation">${ICONS.play}</button>
    </div>
    <div class="fl tools" id="w-tools">
      <button data-t="dup" title="Duplicate selection">${ICONS.dup}</button>
      <button data-t="copy" title="Copy style">${ICONS.copy}</button>
      <button data-t="paste" title="Paste style">${ICONS.paste}</button>
      <button data-t="center" title="Center selection">${ICONS.center}</button>
      <button data-t="size" title="Scale selection">${ICONS.size}</button>
      <button data-t="style" title="Color and effects">${ICONS.style}</button>
      <button data-t="font" title="Text style">${ICONS.font}</button>
      <button data-t="del" title="Delete selection (Del)" hidden>${ICONS.del}</button>
    </div>
    <div class="canvas-wrap" id="w-wrap"><div id="w-stage-slot"></div><div class="empty" id="w-empty" hidden></div></div>
    <div class="fl zoom"><button id="w-zout">−</button><span id="w-zv">100%</span><button id="w-zin">+</button></div>
    <div class="pop" id="w-pop" hidden></div>
  </div>
  <div class="grip" id="w-grip" title="Collapse / expand the animation panel"><i></i></div>
  <div class="ae-card">
    <div id="w-ae"></div>
    <button class="auto-btn" id="w-auto" title="Click a word to style it, Cmd/Ctrl-click for several, drag a box for a whole caption, Shift-click marks the main word. AUTO links this title's entry and exit with its neighbours.">AUTO</button>
  </div>`;
  // the Convert Captions panel lives under the toolbar, like the reference; status text goes to the footer
  root.insertBefore($('#convert-panel'), $('.canvas-row', root));
  const info = document.createElement('div'); info.id = 'w-info'; $('#foot-info').appendChild(info);

  const stage = Preview.make('ws');
  $('#w-stage-slot').appendChild(stage);

  const clone = TF.clone;
  const aspect = () => App.aspect();
  const blocks = () => (W.model ? W.model.blocks : []);
  const selB = () => W.sel.map((i) => blocks()[i]).filter(Boolean);
  const first = () => selB()[0];

  // ---------- history / persistence ----------
  function snapshot() { if (!W.model) return; W.hist.push(JSON.stringify(W.model)); if (W.hist.length > 60) W.hist.shift(); W.fut = []; }
  function undo() { if (!W.hist.length) return; W.fut.push(JSON.stringify(W.model)); W.model = JSON.parse(W.hist.pop()); clampSel(); afterEdit(true); }
  function redo() { if (!W.fut.length) return; W.hist.push(JSON.stringify(W.model)); W.model = JSON.parse(W.fut.pop()); clampSel(); afterEdit(true); }
  function clampSel() { W.sel = W.sel.filter((i) => i < blocks().length); }
  function afterEdit(push) { draw(); if (W.ae) W.ae.refresh(); if (push !== false) schedule(); }

  // In/Out mode: the RANGE stand-in's change since the last send (move, scale, look) is applied to every title in range
  const LOOK_KEYS = ['font', 'fontStyle', 'color', 'glow', 'glowS', 'glowSp', 'glowO', 'tracking', 'opacity', 'case', 'fx'];
  async function saveRange() {
    const cur = W.model && W.model.blocks[0], base = W.rangeBase;
    if (!cur || !base) return;
    const o = { dx: cur.x - base.x, dy: cur.y - base.y, scale: base.size ? cur.size / base.size : 1, set: {} };
    LOOK_KEYS.forEach((k) => { if (JSON.stringify(cur[k]) !== JSON.stringify(base[k])) o.set[k] = cur[k] === undefined ? null : clone(cur[k]); });
    const moved = Math.abs(o.dx) + Math.abs(o.dy) > 1e-4, scaled = Math.abs(o.scale - 1) > 1e-3, looked = Object.keys(o.set).length > 0;
    if (!moved && !scaled && !looked) return;
    W.rangeBase = clone(cur);
    const r = await App.call('updateRangeLook', o);
    if (r.ok) App.msg(`Updated ${r.count} word layer(s) in the In/Out range.`, r.count ? 'ok' : 'err');
  }
  function schedule() {
    if (W.mode === 'inout') { clearTimeout(W.timer); W.timer = setTimeout(saveRange, 700); return; }
    if (W.mode !== 'playhead' || !W.parts.length) return;
    W.dirty = true; clearTimeout(W.timer); W.timer = setTimeout(save, 700);
  }
  const partModel = (p) => {
    const m = clone(p.model);
    m.blocks = blocks().filter((x) => x.uid === p.uid).map((x) => { const y = clone(x); delete y.uid; return y; });
    m.anim = clone(W.anims[p.uid] || p.model.anim);
    return m;
  };
  async function save() {
    if (!W.dirty || !W.model) return;
    W.dirty = false;
    let n = 0, mode = 'animated', reload = false;

    for (const p of W.parts) {
      const m = partModel(p);
      if (!m.blocks.length) continue;
      const j = JSON.stringify(m);
      if (W.saved[p.uid] === j) continue;
      const r = await App.call('updateTitle', { uid: p.uid, model: m });
      if (r.ok) { W.saved[p.uid] = j; n++; if (r.mode !== 'animated') mode = r.mode; }
    }
    // text blocks added in the workspace become new word layers on the next free tracks
    const orphans = blocks().filter((x) => !x.uid);
    if (orphans.length && W.parts.length) {
      const base = W.parts[0], top = Math.max.apply(null, W.parts.map((p) => p.track)) + 1;
      const fps = (App.status && App.status.fps) || 30, st0 = (App.status && App.status.playhead) != null ? App.status.playhead : base.start;
      const items = orphans.map((b, k) => { const y = clone(b); delete y.uid; return { start: st0, end: st0 + Math.round(W.len * fps), track: Math.min(top + k, WL.MAX_TRACK), model: { styleId: W.model.styleId, template: 1, look: 'style', blocks: [y], anim: clone(W.model.anim) } }; });
      const r = await App.call('placeWords', { items });
      if (r.ok) { n += orphans.length - (r.failed || 0); reload = true; }
    }
    if (reload) W.key = null;
    if (n) App.msg(mode === 'animated' ? `Updated ${n} word layer${n > 1 ? 's' : ''}.` : 'Update failed (see Log).', mode === 'animated' ? 'ok' : 'err');
  }

  // ---------- geometry ----------
  const blkEls = () => $$('.blk', stage);
  function boxOf(list) { return TF.bbox(list, aspect()); }
  function placeBox() {
    let box = $('.selbox', stage);
    const list = selB();
    if (!list.length) { if (box) box.remove(); return; }
    if (!box) {
      box = document.createElement('div'); box.className = 'selbox';
      ['nw', 'ne', 'sw', 'se'].forEach((c) => { const h = document.createElement('i'); h.className = 'hd ' + c; h.dataset.c = c; h.addEventListener('pointerdown', startScale); box.appendChild(h); });
      stage.appendChild(box);
    }
    const bb = boxOf(list);
    box.style.left = bb.x0 * 100 + '%'; box.style.top = (1 - bb.y1) * 100 + '%';
    box.style.width = bb.w * 100 + '%'; box.style.height = bb.h * 100 + '%';
  }
  function syncEls() {
    blkEls().forEach((el) => {
      const b = blocks()[+el.dataset.i]; if (!b) return;
      el.style.left = b.x * 100 + '%'; el.style.top = (1 - b.y) * 100 + '%'; el.style.fontSize = b.size * 95 + 'cqh';
    });
    placeBox();
  }

  // ---------- drawing ----------
  function draw() {
    const empty = $('#w-empty');
    stage.style.visibility = W.model ? 'visible' : 'hidden';
    empty.hidden = !!W.model;
    if (!W.model) {
      empty.textContent = W.mode === 'inout' ? 'Set In/Out marks around your titles, then change the animation below.' : 'Park the playhead on a TitleFlow title (or insert one from the Titles tab).';
      return;
    }
    App.setAspect(stage);
    applyZoom();
    if (W.anPlay) { W.anPlay.cancel(); W.anPlay = null; }
    const grp = Preview.render(stage, W.model);
    $$('.blk', grp).forEach((el) => {
      const i = +el.dataset.i;
      el.classList.toggle('sel', W.sel.includes(i));
      el.classList.toggle('main', W.main === i);
      el.addEventListener('pointerdown', (e) => startDrag(e, i));
      el.addEventListener('dblclick', () => editText(i));
      el.addEventListener('contextmenu', (e) => { e.preventDefault(); editText(i); });
    });
    placeBox();
    $('#w-info').dataset.n = W.sel.length;
  }

  function setSel(list) { W.sel = list; draw(); W.ae && W.ae.refresh(); if (!$('#w-pop').hidden && W.popKind) openStylePop(true); }

  // select / move
  function startDrag(e, i) {
    if (e.button !== 0) return; // right-click edits the text (contextmenu), it doesn't select or drag
    e.preventDefault(); e.stopPropagation();
    // Shift-click: mark the main (biggest) word for Template 1 (yellow border). Cmd/Ctrl-click: add to the selection.
    if (e.shiftKey) { W.main = W.main === i ? null : i; draw(); App.msg(W.main == null ? 'Main word cleared.' : 'Main word set. Click Template 1 to make it the big word.', 'ok'); return; }
    if (e.metaKey || e.ctrlKey) {
      setSel(W.sel.includes(i) ? W.sel.filter((k) => k !== i) : W.sel.concat(i));
      return;
    }
    if (!W.sel.includes(i)) setSel([i]);
    const list = selB(), r = stage.getBoundingClientRect();
    const sx = e.clientX, sy = e.clientY, orig = list.map((b) => [b.x, b.y]);
    let moved = false;
    snapshot();
    // listen on the window: selecting a word redraws the canvas, which replaces the element that was pressed
    const mv = (ev) => {
      const dx = (ev.clientX - sx) / r.width, dy = (ev.clientY - sy) / r.height;
      if (Math.abs(dx) + Math.abs(dy) > 0.004) moved = true;
      list.forEach((b, k) => { b.x = TF.clamp(orig[k][0] + dx, 0, 1); b.y = TF.clamp(orig[k][1] - dy, 0, 1); });
      syncEls();
    };
    const up = () => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
      if (moved) afterEdit(); else { W.hist.pop(); openStylePop(); }
    };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  }

  // marquee selection on empty canvas
  stage.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || !W.model || e.target.closest('.blk') || e.target.closest('.hd') || e.target.closest('.inline-edit')) return;
    e.preventDefault();
    const r = stage.getBoundingClientRect();
    const x0 = (e.clientX - r.left) / r.width, y0 = 1 - (e.clientY - r.top) / r.height;
    const add = e.shiftKey;
    const base = add ? W.sel.slice() : [];
    const m = document.createElement('div'); m.className = 'marquee'; stage.appendChild(m);
    stage.setPointerCapture(e.pointerId);
    let moved = false;
    const mv = (ev) => {
      const x1 = (ev.clientX - r.left) / r.width, y1 = 1 - (ev.clientY - r.top) / r.height;
      if (Math.abs(x1 - x0) + Math.abs(y1 - y0) > 0.01) moved = true;
      const a = Math.min(x0, x1), b = Math.max(x0, x1), c = Math.min(y0, y1), d = Math.max(y0, y1);
      m.style.left = a * 100 + '%'; m.style.width = (b - a) * 100 + '%'; m.style.top = (1 - d) * 100 + '%'; m.style.height = (d - c) * 100 + '%';
      const hit = [];
      blocks().forEach((bl, k) => { const bb = boxOf([bl]); if (bb.x1 >= a && bb.x0 <= b && bb.y1 >= c && bb.y0 <= d) hit.push(k); });
      W.sel = Array.from(new Set(base.concat(hit)));
      $$('.blk', stage).forEach((el) => el.classList.toggle('sel', W.sel.includes(+el.dataset.i)));
      placeBox();
    };
    const up = () => {
      stage.removeEventListener('pointermove', mv); stage.removeEventListener('pointerup', up);
      m.remove();
      if (!moved && !add) W.sel = [];
      draw(); W.ae && W.ae.refresh();
    };
    stage.addEventListener('pointermove', mv); stage.addEventListener('pointerup', up);
  });

  // scale the selection from a corner handle
  function startScale(e) {
    e.preventDefault(); e.stopPropagation();
    const list = selB(); if (!list.length) return;
    const r = stage.getBoundingClientRect();
    const bb = boxOf(list);
    const cx = r.left + bb.cx * r.width, cy = r.top + (1 - bb.cy) * r.height;
    const d0 = Math.max(10, Math.hypot(e.clientX - cx, e.clientY - cy));
    const orig = list.map((b) => ({ s: b.size, x: b.x, y: b.y }));
    snapshot();
    const h = e.currentTarget; h.setPointerCapture(e.pointerId);
    const mv = (ev) => {
      const k = TF.clamp(Math.hypot(ev.clientX - cx, ev.clientY - cy) / d0, 0.2, 5);
      list.forEach((b, n) => { b.size = TF.clamp(orig[n].s * k, 0.008, 0.35); b.x = bb.cx + (orig[n].x - bb.cx) * k; b.y = bb.cy + (orig[n].y - bb.cy) * k; });
      syncEls();
    };
    const up = () => { h.removeEventListener('pointermove', mv); h.removeEventListener('pointerup', up); afterEdit(); };
    h.addEventListener('pointermove', mv); h.addEventListener('pointerup', up);
  }

  function editText(i) {
    const b = blocks()[i]; if (!b) return;
    const inp = document.createElement('input');
    inp.className = 'inline-edit'; inp.value = b.text;
    inp.style.left = b.x * 100 + '%'; inp.style.top = (1 - b.y) * 100 + '%';
    stage.appendChild(inp); inp.focus(); inp.select();
    let fin = false;
    const done = (ok) => {
      if (fin || !inp.parentNode) return;
      fin = true;
      const v = inp.value.trim(); inp.remove();
      if (ok && v && v !== b.text) { snapshot(); b.text = v; afterEdit(); } else draw();
    };
    inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); });
    inp.addEventListener('blur', () => done(true));
  }

  // ---------- loading from Resolve ----------
  async function poll() {
    if (!root.classList.contains('active') || W.busy || W.dirty || W.sample) return;
    W.busy = true;
    try {
      if (W.mode === 'inout') {
        const io = App.status && App.status.inOut;
        $('#w-info').innerHTML = io ? "<b>In/Out set</b> <span class=\"mute\">· drag or restyle RANGE to move / restyle every title in range; animation changes apply to all of them</span>" : '<span class="mute">Set In/Out marks (I and O) on the timeline.</span>';
        if (!W.model) { W.model = { blocks: [{ text: 'RANGE', role: 'big', size: 0.06, font: 'Montserrat', fontStyle: 'Bold', color: [1, 1, 1], glow: false, x: 0.5, y: 0.5 }], anim: clone(TF.STYLES[1].anim) }; W.rangeBase = clone(W.model.blocks[0]); W.uid = null; W.sel = [0]; draw(); W.ae && W.ae.refresh(); }
        return;
      }
      const r = await window.tf.captionAtPlayhead();
      if (!r || r.ok === false) { $('#w-info').textContent = (r && r.error) || ''; return; }
      if (r.none) {
        if (W.parts.length || W.model) { W.parts = []; W.key = null; W.uid = null; W.model = null; W.sel = []; W.hist = []; W.fut = []; draw(); W.ae && W.ae.refresh(); }
        $('#w-info').innerHTML = '<span class="mute">No TitleFlow title under the playhead. Move the playhead onto a caption.</span>';
        return;
      }
      const key = r.parts.map((p) => p.uid).join(',');
      $('#w-info').innerHTML = `<b>Editing caption</b> <span class="mute">· ${r.parts.length} word layer${r.parts.length > 1 ? 's' : ''} · ${esc(r.tc)}</span>`;
      if (key !== W.key) {
        W.key = key; W.parts = r.parts; W.uid = r.parts[0].uid; W.anims = {}; W.saved = {}; W.main = null;
        const bl = [];
        r.parts.forEach((p) => { W.anims[p.uid] = clone(p.model.anim); p.model.blocks.forEach((b) => bl.push(Object.assign(clone(b), { uid: p.uid }))); W.saved[p.uid] = JSON.stringify(Object.assign(clone(p.model), { blocks: p.model.blocks, anim: p.model.anim })); });
        W.model = { styleId: r.parts[0].model.styleId, template: r.parts[0].model.template, look: r.parts[0].model.look, blocks: bl, anim: clone(r.parts[0].model.anim) };
        W.sel = bl.length ? [0] : []; W.hist = []; W.fut = []; draw(); W.ae && W.ae.refresh();
      }
    } catch (e) { App.log('workspace poll: ' + e.message); } finally { W.busy = false; }
  }

  // ---------- top controls ----------
  seg($('#w-mode'), () => W.mode, (v) => { W.mode = v; W.uid = null; W.model = null; W.parts = []; W.key = null; W.sel = []; draw(); poll(); });
  seg($('#w-tpl'), () => W.tpl, (v) => {
    W.tpl = +v; if (!W.model) return;
    snapshot();
    const st = App.style(W.model.styleId), old = W.model.blocks, words = old.map((b) => b.text);
    const lo = { aspect: aspect(), center: [0.5, 0.5], look: W.model.look || 'style' };
    const main = W.tpl === 1 && W.main != null && W.main < old.length ? W.main : null;
    if (main != null) {
      // Template 1 around the main word: words before it above (small), the main word big, words after it below
      const pre = [], post = []; words.forEach((_, k) => { if (k < main) pre.push(k); else if (k > main) post.push(k); });
      const lines = [], roles = [];
      if (pre.length) { lines.push(pre); roles.push('small'); }
      lines.push([main]); roles.push('big');
      if (post.length) { lines.push(post); roles.push('small'); }
      W.model.blocks = TF.explode(TF.layoutLines(words, lines, roles, st, lo), aspect());
    } else W.model.blocks = TF.explode(TF.layout(words, W.tpl, st, lo), aspect());
    // keep the user's own styling, except when a main word was chosen (then the template's big/small look is the point)
    W.model.blocks.forEach((b, k) => { if (old[k]) { b.uid = old[k].uid; if (main == null) ['color', 'glow', 'font', 'fontStyle', 'fx', 'tracking', 'opacity', 'case'].forEach((p) => { if (old[k][p] !== undefined) b[p] = clone(old[k][p]); }); } });
    W.sel = []; afterEdit();
  });
  // Shift-click a template: also apply its recommended animation
  const TPL_ANIM = { 1: ['up', 'up'], 2: ['left', 'right'], 3: ['down', 'down'] };
  $('#w-tpl').addEventListener('click', (e) => {
    if (!e.shiftKey || !W.model || !e.target.closest('button')) return;
    const [di, dout] = TPL_ANIM[W.tpl];
    const a = clone(W.model.anim || TF.STYLES[1].anim);
    Object.assign(a.in, { slide: true, dir: di, frames: 10 }); Object.assign(a.out, { slide: true, dir: dout, frames: 10 });
    W.model.anim = a; W.parts.forEach((p) => { W.anims[p.uid] = clone(a); });
    afterEdit(); App.msg(`Template ${W.tpl} with its recommended animation (in ${di}, out ${dout}).`, 'ok');
  });
  $('#w-addtext').addEventListener('click', () => {
    if (!W.model) {
      const st = App.status || {}, fps = st.fps || 30, style = App.style(App.styles()[0].id);
      const blk = TF.explode(TF.layout(['TEXT'], 1, style, { aspect: aspect(), center: [0.5, 0.5], look: 'style' }), aspect());
      blk.forEach((b, k) => { b.wi = k; });
      const model = { styleId: style.id, template: 1, look: 'style', blocks: blk, anim: TF.clone(style.anim) };
      const start = st.playhead || 0, end = start + Math.round(W.len * fps);
      App.msg('Inserting text…');
      return WL.place(WL.items(model, blk.map(() => start), end, 2)).then((r) => App.msg(r && r.ok && !r.failed ? 'Text inserted.' : 'Insert failed (see Log).', r && r.ok ? 'ok' : 'err'));
    }
    snapshot();
    const last = blocks()[blocks().length - 1] || { size: 0.05, font: 'Montserrat', fontStyle: 'Bold', color: [1, 1, 1], glow: false, y: 0.5 };
    const nb = clone(last); delete nb.uid; nb.text = 'TEXT'; nb.role = 'small'; nb.x = 0.5; nb.y = TF.clamp(last.y - last.size * 1.3, 0.05, 0.95);
    W.model.blocks.push(nb); W.sel = [W.model.blocks.length - 1]; afterEdit();
  });
  slider($('#w-len'), $('#w-len-v'), (v) => v.toFixed(1) + ' s', (v) => { W.len = v; });
  $('#w-undo').addEventListener('click', undo);
  $('#w-redo').addEventListener('click', redo);
  $('#w-play').addEventListener('click', () => { if (!W.model) return; const g = $('.grp', stage); if (g) W.anPlay = Preview.play(g, W.model); });
  $('#w-all').addEventListener('click', () => { if (W.model) setSel(blocks().map((_, i) => i)); });

  // align: within the selection if several are selected, otherwise the whole caption
  $$('.canvas-bar [data-a]').forEach((b) => b.addEventListener('click', () => {
    if (!W.model) return; snapshot();
    const list = W.sel.length > 1 ? selB() : blocks();
    TF.alignBlocks(list, b.dataset.a, aspect()); afterEdit();
  }));
  ($('#w-fit') || document.createElement('i')).addEventListener('click', () => {
    if (!W.model) return; snapshot();
    const list = W.sel.length > 1 ? selB() : blocks();
    const bb = boxOf(list), k = Math.min(1, 0.88 / Math.max(bb.w, 0.01));
    list.forEach((b) => { b.size *= k; b.x = 0.5 + (b.x - bb.cx) * k; b.y = 0.5 + (b.y - bb.cy) * k; });
    afterEdit();
  });
  $('#w-reset').addEventListener('click', () => {
    if (!W.model) return; snapshot();
    const st = App.style(W.model.styleId), old = W.model.blocks;
    W.model.blocks = TF.explode(TF.layout(old.map((b) => b.text), W.tpl, st, { aspect: aspect(), center: [0.5, 0.5] }), aspect());
    W.model.blocks.forEach((b, k) => { if (old[k]) b.uid = old[k].uid; });
    W.sel = []; afterEdit();
  });

  // zoom
  function applyZoom() { $('#w-stage-slot').style.width = Math.round(W.zoom * 430 * App.aspect()) + 'px'; $('#w-zv').textContent = Math.round(W.zoom * 100) + '%'; }
  $('#w-zin').addEventListener('click', () => { W.zoom = Math.min(2, +(W.zoom + 0.1).toFixed(2)); applyZoom(); });
  $('#w-zout').addEventListener('click', () => { W.zoom = Math.max(0.4, +(W.zoom - 0.1).toFixed(2)); applyZoom(); });
  $('#w-zv').addEventListener('click', () => { W.zoom = 1; applyZoom(); });
  $('#w-grip').addEventListener('click', () => { const a = $('.ae-card', root); a.hidden = !a.hidden; });

  // video frame behind the canvas
  async function grabFrame() {
    const r = await App.call('frame');
    if (r.ok && r.dataUrl) { W.bg = r.dataUrl; stage.style.background = `#000 url(${r.dataUrl}) center/cover no-repeat`; }
    else if (r.ok) App.msg(r.warning || 'Resolve did not return a frame.', 'err');
  }
  $('#w-video').addEventListener('click', async () => {
    W.video = !W.video; $('#w-video').classList.toggle('on', W.video);
    if (W.video) { App.msg('Grabbing the current frame… park the playhead on video without a title for a clean background.'); await grabFrame(); }
    else stage.style.background = '';
  });

  // ---------- tool strip ----------
  let clip = null;
  const pop = $('#w-pop');
  document.addEventListener('pointerdown', (e) => { if (!pop.hidden && !pop.contains(e.target) && !e.target.closest('#w-tools') && !e.target.closest('#w-wrap') && !e.target.closest('.selbox')) { pop.hidden = true; W.popKind = null; } });
  const STYLE_KEYS = ['font', 'fontStyle', 'color', 'glow', 'glowS', 'glowSp', 'glowO', 'size', 'tracking', 'opacity', 'case', 'fx'];
  $('#w-tools').addEventListener('click', (e) => {
    const t = e.target.closest('button'); if (!t || !W.model) return;
    const list = selB(); const kind = t.dataset.t;
    if (!list.length && kind !== 'paste') return App.msg('Click a word (or drag a box over several) first.', 'err');
    if (kind === 'dup') {
      snapshot(); const start = blocks().length;
      list.forEach((b) => { const n = clone(b); delete n.uid; n.y = TF.clamp(b.y - b.size * 1.3, 0.03, 0.97); W.model.blocks.push(n); });
      W.sel = list.map((_, k) => start + k); afterEdit();
    } else if (kind === 'copy') {
      clip = {}; STYLE_KEYS.forEach((k) => { if (list[0][k] !== undefined) clip[k] = clone(list[0][k]); }); App.msg('Style copied.', 'ok');
    } else if (kind === 'paste') {
      if (!clip) return App.msg('Copy a style first.', 'err'); if (!list.length) return;
      // choose what to paste: everything, only the look, only the font, or size and tracking
      const PASTE = { all: STYLE_KEYS, look: ['color', 'glow', 'glowS', 'glowSp', 'glowO', 'opacity', 'fx'], font: ['font', 'fontStyle', 'case'], size: ['size', 'tracking'] };
      pop.hidden = false; W.popKind = 'paste'; pop.classList.remove('wide', 'spcard');
      pop.innerHTML = `<div class="ae-pop-h"><b>Paste style</b><button class="x">×</button></div>
        <div class="pastegrid"><button data-p="all">Everything</button><button data-p="look">Look (colour, glow, effects)</button><button data-p="font">Font</button><button data-p="size">Size &amp; tracking</button></div>`;
      $('.x', pop).onclick = () => { pop.hidden = true; W.popKind = null; };
      $$('[data-p]', pop).forEach((bt) => { bt.onclick = () => {
        snapshot();
        selB().forEach((b) => PASTE[bt.dataset.p].forEach((k) => { if (clip[k] === undefined) delete b[k]; else b[k] = clone(clip[k]); }));
        pop.hidden = true; W.popKind = null; afterEdit(); App.msg('Pasted: ' + bt.textContent + '.', 'ok');
      }; });
    } else if (kind === 'center') {
      snapshot(); const bb = boxOf(list); list.forEach((b) => { b.x += 0.5 - bb.cx; }); afterEdit();
    } else if (kind === 'del') {
      if (list.length >= blocks().length) return App.msg('A title needs at least one block.', 'err');
      snapshot(); W.model.blocks = blocks().filter((_, i) => !W.sel.includes(i)); W.sel = [];
      const left = new Set(blocks().map((b) => b.uid)); const gone = Array.from(new Set(list.map((b) => b.uid).filter((u) => u && !left.has(u))));
      if (!gone.length) schedule();
      if (gone.length) App.call('deleteTitles', { uids: gone }).then((r) => { if (r.ok) { App.msg(`Deleted ${r.count} title(s).`, 'ok'); W.key = null; } });
      afterEdit(false);
    } else if (kind === 'size') {
      pop.hidden = false; W.popKind = 'size';
      pop.innerHTML = '<label>Scale selection</label><input type="range" min="0.5" max="2" step="0.01" value="1"><span class="val">100%</span>';
      const r = $('input', pop), v = $('.val', pop), bb = boxOf(list), orig = list.map((b) => ({ s: b.size, x: b.x, y: b.y }));
      let first = true;
      r.addEventListener('input', () => {
        if (first) { snapshot(); first = false; }
        const k = parseFloat(r.value); v.textContent = Math.round(k * 100) + '%';
        list.forEach((b, n) => { b.size = TF.clamp(orig[n].s * k, 0.008, 0.35); b.x = bb.cx + (orig[n].x - bb.cx) * k; b.y = bb.cy + (orig[n].y - bb.cy) * k; });
        syncEls();
      });
      r.addEventListener('change', () => afterEdit());
    } else openStylePop();
  });

  // ---------- text style card (opens when a word is clicked) ----------
  // Layout follows the reference: text + favourite + close; font, search, weight; colour + case; Size/Tracking/Opacity;
  // Gradient / Borders / Outline / Shadow / Glow / Blur chips with their own settings and a "Turn off" button; Position / Style resets.
  let fxTab = 'gradient', gStop = 1, fontSearch = false;
  const FX = {
    gradient: { on: (b) => !!(b.fx && b.fx.gradient), def: (b) => ({ c1: (b.color || [1, 1, 1]).slice(), c2: [0.25, 0.25, 0.25], p1: 0, p2: 1, angle: 90 }) },
    border: { on: (b) => !!(b.fx && b.fx.border), def: () => ({ w: 0.02 }) },
    outline: { on: (b) => !!(b.fx && b.fx.outline), def: () => ({ w: 0.02, color: [0, 0, 0] }) },
    shadow: { on: (b) => !!(b.fx && b.fx.shadow), def: () => ({ blur: 0.25, opacity: 0.6 }) },
    glow: { on: (b) => !!b.glow },
    blur: { on: (b) => !!(b.fx && b.fx.blur), def: () => ({ amt: 2 }) },
  };
  const NAMES = { gradient: 'Gradient', border: 'Borders', outline: 'Outline', shadow: 'Shadow', glow: 'Glow', blur: 'Blur' };
  const num = (v, d) => (v == null ? d : v);
  const fmt = (v, step) => Number(v).toFixed(step < 0.001 ? 4 : step < 0.01 ? 3 : step < 1 ? 2 : 0).replace(/\.?0+$/, '') || '0';

  function openStylePop(keep) {
    const list = selB(); const b = list[0]; if (!b) { pop.hidden = true; return; }
    W.popKind = 'style'; pop.hidden = false; pop.classList.add('wide', 'spcard');
    const fxo = b.fx || {};
    const single = list.length === 1;
    const sl = (label, key, lo, hi, step, v) => `<div class="sp-sl"><label>${label}</label><input type="range" data-k="${key}" min="${lo}" max="${hi}" step="${step}" value="${v}"><span class="val">${fmt(v, step)}</span></div>`;
    const on = fxTab === 'glow' ? !!b.glow : FX[fxTab].on(b);
    let panel = '';
    if (fxTab === 'gradient' && on) {
      const gr = fxo.gradient, sc = gStop === 1 ? gr.c1 : gr.c2, sp = gStop === 1 ? num(gr.p1, 0) : num(gr.p2, 1);
      panel = `<div class="gbar" style="background:linear-gradient(90deg,${hex(gr.c1)} ${num(gr.p1, 0) * 100}%,${hex(gr.c2)} ${num(gr.p2, 1) * 100}%)">
          <i class="gstop ${gStop === 1 ? 'sel' : ''}" data-s="1" style="left:${num(gr.p1, 0) * 100}%"></i><i class="gstop ${gStop === 2 ? 'sel' : ''}" data-s="2" style="left:${num(gr.p2, 1) * 100}%"></i></div>
        <div class="sp-row"><label class="swatch sm" style="background:${hex(sc)}"><input type="color" id="sp-gc" value="${hex(sc)}"></label><span class="mute" id="sp-gp">${Math.round(sp * 100)}%</span><span class="grow"></span><button class="pillbtn on" id="sp-solid">Solid</button></div>
        ${sl('Angle', 'gangle', 0, 360, 1, num(gr.angle, 90))}`;
    }
    if (fxTab === 'border' && on) panel = sl('Width', 'bw', 0.005, 0.08, 0.005, num(fxo.border.w, 0.02));
    if (fxTab === 'outline' && on) panel = sl('Width', 'ow', 0.005, 0.08, 0.005, num(fxo.outline.w, 0.02)) + `<div class="sp-sl"><label>Color</label><label class="swatch sm" style="background:${hex(num(fxo.outline.color, [0, 0, 0]))}"><input type="color" data-k="oc" value="${hex(num(fxo.outline.color, [0, 0, 0]))}"></label></div>`;
    if (fxTab === 'shadow' && on) panel = sl('Blur', 'sb', 0, 1, 0.01, num(fxo.shadow.blur, 0.25)) + sl('Opacity', 'so', 0, 1, 0.01, num(fxo.shadow.opacity, 0.6));
    if (fxTab === 'glow' && on) panel = sl('Strength', 'gs', 0.2, 3, 0.05, num(b.glowS, 1)) + sl('Spread', 'gsp', 0.2, 3, 0.05, num(b.glowSp, 1)) + sl('Opacity', 'go', 0, 1, 0.01, num(b.glowO, 1));
    if (fxTab === 'blur' && on) panel = sl('Amount', 'ba', 0, 10, 0.1, num(fxo.blur.amt, 2));
    const fonts = FONTS.concat(FONTS.includes(b.font) ? [] : [b.font]);
    pop.innerHTML = `
      <div class="sp-row"><input id="sp-text" class="grow" value="${esc(single ? b.text : '(' + list.length + ' words)')}" ${single ? '' : 'disabled'}><button class="sq" id="sp-star" title="Save this look to the gallery">★</button><button class="x" id="sp-x" title="Close">×</button></div>
      <div class="sp-row"><select id="sp-font" class="grow">${fonts.map((f) => `<option ${f === b.font ? 'selected' : ''}>${esc(f)}</option>`).join('')}</select><button class="sq" id="sp-search" title="Use any installed font by name">${ICONS.search}</button><select id="sp-w" class="grow">${WEIGHTS.map((f) => `<option ${f === b.fontStyle ? 'selected' : ''}>${f}</option>`).join('')}</select></div>
      <div class="sp-row" id="sp-fontrow" ${fontSearch ? '' : 'hidden'}><input id="sp-fontq" class="grow" placeholder="Type a font name, e.g. Bebas Neue" value=""><button class="pillbtn" id="sp-fontok">Use</button></div>
      <div class="sp-row"><label class="swatch" style="background:${fxo.gradient ? `linear-gradient(135deg,${hex(fxo.gradient.c1)},${hex(fxo.gradient.c2)})` : hex(b.color)}"><input type="color" id="sp-color" value="${hex(b.color)}"></label><span class="grow"></span>
        <div class="seg" id="sp-case"><button data-v="lower">aa</button><button data-v="none">Aa</button><button data-v="upper">AA</button></div></div>
      ${sl('Size', 'size', 0.01, 0.3, 0.0001, b.size)}${sl('Tracking', 'track', 0, 3, 0.05, num(b.tracking, 1))}${sl('Opacity', 'opac', 0, 1, 0.01, num(b.opacity, 1))}
      <div class="sp-sep"></div>
      <div class="sp-chips">${Object.keys(FX).map((k) => `<button data-fx="${k}" class="${fxTab === k && FX[k].on(b) ? 'on' : ''}${FX[k].on(b) ? ' lit' : ''}">${NAMES[k]}</button>`).join('')}</div>
      ${on ? `<div class="sp-panel">${panel}<button class="offbtn" id="sp-toggle">⏻ Turn off ${NAMES[fxTab]}</button></div>` : ''}
      <div class="sp-row sp-foot"><button class="pillbtn" id="sp-pos">↺ Position</button><span class="grow"></span><button class="pillbtn" id="sp-sty">↺ Style</button></div>`;
    const each = (fn) => { list.forEach(fn); };
    const commit = (fn, redraw) => { if (!pop._snap) { snapshot(); pop._snap = true; } fn(); if (redraw) afterEdit(false); else syncEls(); };
    const finish = () => { pop._snap = false; schedule(); };
    const reopen = () => openStylePop(true);
    $('#sp-x').onclick = () => { pop.hidden = true; W.popKind = null; };
    $('#sp-star').onclick = () => App.openGallery && App.openGallery(W.model, W.sel);
    if (single) $('#sp-text').oninput = (e) => { commit(() => { b.text = e.target.value; }, false); const el = blkEls()[W.sel[0]]; if (el) el.textContent = b.text; };
    $('#sp-text').onchange = finish;
    $('#sp-font').onchange = (e) => { commit(() => each((x) => { x.font = e.target.value; }), true); finish(); reopen(); };
    $('#sp-search').onclick = () => { fontSearch = !fontSearch; reopen(); if (fontSearch) $('#sp-fontq').focus(); };
    const useFont = () => { const v = $('#sp-fontq').value.trim(); if (!v) return; if (!FONTS.includes(v)) FONTS.push(v); fontSearch = false; commit(() => each((x) => { x.font = v; }), true); finish(); reopen(); };
    $('#sp-fontok').onclick = useFont;
    $('#sp-fontq').onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter') useFont(); };
    $('#sp-w').onchange = (e) => { commit(() => each((x) => { x.fontStyle = e.target.value; }), true); finish(); };
    $('#sp-color').oninput = (e) => { commit(() => each((x) => { x.color = unhex(e.target.value); if (x.fx && x.fx.gradient) delete x.fx.gradient; }), true); e.target.parentNode.style.background = e.target.value; };
    $('#sp-color').onchange = () => { finish(); reopen(); };
    $$('#sp-case button').forEach((bt) => { bt.classList.toggle('on', (b.case || 'none') === bt.dataset.v); bt.onclick = () => { commit(() => each((x) => { x.case = bt.dataset.v === 'none' ? undefined : bt.dataset.v; }), true); finish(); reopen(); }; });
    $$('input[type=range]', pop).forEach((r) => {
      const v = r.nextElementSibling; const k = r.dataset.k;
      r.oninput = () => {
        const x = parseFloat(r.value); v.textContent = fmt(x, parseFloat(r.step));
        commit(() => each((t) => {
          t.fx = t.fx || {};
          if (k === 'size') t.size = x; else if (k === 'track') t.tracking = x; else if (k === 'opac') t.opacity = x;
          else if (k === 'gangle') (t.fx.gradient = t.fx.gradient || FX.gradient.def(t)).angle = x;
          else if (k === 'bw') (t.fx.border = t.fx.border || FX.border.def()).w = x;
          else if (k === 'ow') (t.fx.outline = t.fx.outline || FX.outline.def()).w = x;
          else if (k === 'sb') (t.fx.shadow = t.fx.shadow || FX.shadow.def()).blur = x;
          else if (k === 'so') (t.fx.shadow = t.fx.shadow || FX.shadow.def()).opacity = x;
          else if (k === 'gs') { t.glow = true; t.glowS = x; } else if (k === 'gsp') { t.glow = true; t.glowSp = x; } else if (k === 'go') { t.glow = true; t.glowO = x; }
          else if (k === 'ba') (t.fx.blur = t.fx.blur || FX.blur.def()).amt = x;
        }), true);
        if (k === 'gangle' && $('.gbar', pop)) { /* bar shows stops left to right; the angle applies to the text */ }
      };
      r.onchange = () => { finish(); };
    });
    $$('input[type=color][data-k=oc]', pop).forEach((c) => { c.oninput = (e) => { commit(() => each((t) => { t.fx = t.fx || {}; (t.fx.outline = t.fx.outline || FX.outline.def()).color = unhex(e.target.value); }), true); c.parentNode.style.background = e.target.value; }; c.onchange = finish; });
    // gradient: pick a stop, drag it along the bar, set its colour; Solid goes back to one colour
    const bar = $('.gbar', pop);
    if (bar) {
      $$('.gstop', bar).forEach((h) => h.addEventListener('pointerdown', (e) => {
        e.preventDefault(); gStop = +h.dataset.s; $$('.gstop', bar).forEach((x) => x.classList.toggle('sel', x === h));
        const r = bar.getBoundingClientRect(); h.setPointerCapture(e.pointerId);
        const mv = (ev) => {
          const p = TF.clamp((ev.clientX - r.left) / r.width, 0, 1);
          commit(() => each((t) => { const gr = (t.fx = t.fx || {}).gradient = (t.fx.gradient || FX.gradient.def(t)); gr[gStop === 1 ? 'p1' : 'p2'] = p; }), true);
          h.style.left = p * 100 + '%'; $('#sp-gp').textContent = Math.round(p * 100) + '%';
          const gr = b.fx.gradient; bar.style.background = `linear-gradient(90deg,${hex(gr.c1)} ${gr.p1 * 100}%,${hex(gr.c2)} ${gr.p2 * 100}%)`;
        };
        const up = () => { h.removeEventListener('pointermove', mv); h.removeEventListener('pointerup', up); finish(); reopen(); };
        h.addEventListener('pointermove', mv); h.addEventListener('pointerup', up);
      }));
      $('#sp-gc').oninput = (e) => { commit(() => each((t) => { const gr = (t.fx = t.fx || {}).gradient = (t.fx.gradient || FX.gradient.def(t)); gr[gStop === 1 ? 'c1' : 'c2'] = unhex(e.target.value); }), true); e.target.parentNode.style.background = e.target.value; };
      $('#sp-gc').onchange = () => { finish(); reopen(); };
      $('#sp-solid').onclick = () => { commit(() => each((t) => { if (t.fx) delete t.fx.gradient; }), true); finish(); reopen(); };
    }
    // chips: clicking one turns that effect on and shows its settings; "Turn off" removes it
    $$('.sp-chips button', pop).forEach((bt) => { bt.onclick = () => {
      fxTab = bt.dataset.fx;
      const isOn = fxTab === 'glow' ? !!b.glow : FX[fxTab].on(b);
      if (!isOn) { commit(() => each((t) => { t.fx = t.fx || {}; if (fxTab === 'glow') { t.glow = true; if (t.glowS == null) t.glowS = 1; } else { if (fxTab === 'outline') delete t.fx.border; if (fxTab === 'border') delete t.fx.outline; t.fx[fxTab] = FX[fxTab].def(t); } }), true); finish(); }
      reopen();
    }; });
    if ($('#sp-toggle')) $('#sp-toggle').onclick = () => { commit(() => each((t) => { if (fxTab === 'glow') t.glow = false; else if (t.fx) delete t.fx[fxTab]; }), true); finish(); reopen(); };
    $('#sp-pos').onclick = () => {
      snapshot(); const st = App.style(W.model.styleId);
      const lay = TF.explode(TF.layout(blocks().map((x) => x.text), W.tpl, st, { aspect: aspect(), center: [0.5, 0.5] }), aspect());
      W.sel.forEach((i) => { if (lay[i]) { blocks()[i].x = lay[i].x; blocks()[i].y = lay[i].y; } }); afterEdit();
    };
    $('#sp-sty').onclick = () => {
      snapshot(); const st = App.style(W.model.styleId);
      const lay = TF.explode(TF.layout(blocks().map((x) => x.text), W.tpl, st, { aspect: aspect(), center: [0.5, 0.5] }), aspect());
      W.sel.forEach((i) => { const l = lay[i], t = blocks()[i]; if (l) { ['font', 'fontStyle', 'color', 'glow', 'size'].forEach((k) => { t[k] = clone(l[k]); }); delete t.fx; delete t.tracking; delete t.opacity; delete t.case; delete t.glowS; delete t.glowSp; delete t.glowO; } }); afterEdit(); reopen();
    };
  }

  // ---------- animation panel ----------
  const selUids = () => { const u = Array.from(new Set(selB().map((b) => b.uid).filter(Boolean))); return u.length ? u : W.parts.map((p) => p.uid); };
  W.ae = AnimEditor.mount($('#w-ae'), {
    get: () => {
      if (!W.model) return null;
      if (W.mode === 'inout') return W.model.anim;
      const u = selUids()[0];
      return (u && W.anims[u]) || W.model.anim;
    },
    set: (a) => {
      if (!W.model) return;
      if (W.mode === 'inout') { W.model.anim = a; clearTimeout(W.timer); W.timer = setTimeout(async () => { const r = await App.call('updateRange', { anim: W.model.anim }); if (r.ok) App.msg(`Animation applied to ${r.count} title(s) in range.`, r.count ? 'ok' : 'err'); }, 700); return; }
      selUids().forEach((u) => { W.anims[u] = clone(a); });
      W.model.anim = clone(a);
      schedule();
    },
  });

  $('#w-auto').addEventListener('click', async () => {
    if (!W.parts.length) return App.msg('Park the playhead on a TitleFlow caption first.', 'err');
    if (W.dirty) await save();
    App.msg('Matching…');
    const uid = selUids()[0];
    const r = await App.call('autoMatch', { uid });
    if (r.ok) { App.msg(`Matched ${r.updated.length} layer(s).`, 'ok'); W.key = null; poll(); }
  });

  document.addEventListener('keydown', (e) => {
    if (!root.classList.contains('active') || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    const mod = e.metaKey || e.ctrlKey;
    if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    else if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); $('#w-all').click(); }
    else if ((e.key === 'Delete' || e.key === 'Backspace') && W.sel.length) { e.preventDefault(); $('#w-tools [data-t=del]').click(); }
    else if (e.key.startsWith('Arrow') && W.sel.length) {
      e.preventDefault(); snapshot();
      const st = e.shiftKey ? 0.01 : 0.002;
      selB().forEach((b) => { if (e.key === 'ArrowLeft') b.x -= st; if (e.key === 'ArrowRight') b.x += st; if (e.key === 'ArrowUp') b.y += st; if (e.key === 'ArrowDown') b.y -= st; });
      afterEdit();
    }
  });

  // Convert Captions: the canvas shows one "sample" word; its look and animation are used for every converted word
  function enterSample(model) {
    W.sample = true; W.parts = []; W.key = null; W.uid = null; W.mode = 'playhead';
    W.model = clone(model); W.sel = [0]; W.hist = []; W.fut = [];
    $('#w-info').innerHTML = '<b>Styling the sample word</b> <span class="mute">· click it to change size, case, colour, glow, outline…, then Convert</span>';
    draw(); W.ae && W.ae.refresh();
  }
  function exitSample() { if (!W.sample) return; W.sample = false; W.model = null; W.key = null; W.sel = []; pop.hidden = true; draw(); W.ae && W.ae.refresh(); poll(); }
  const sampleModel = () => (W.sample && W.model ? clone(W.model) : null);

  App.on('status', () => { if (stage) App.setAspect(stage); });
  App.on('show:workspace', () => { poll(); });
  setInterval(poll, 1500);
  draw();
  return { W, poll, enterSample, exitSample, sampleModel };
})();
