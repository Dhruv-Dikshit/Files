// Startup: status polling, tab switching, log panel, Convert Captions.
(async function boot() {
  $$('.tab').forEach((b) => b.addEventListener('click', () => App.showTab(b.dataset.tab)));

  async function poll() {
    try {
      const r = await window.tf.status();
      if (r && r.ok) {
        App.status = r;
        $('#status').textContent = `${r.timeline.toUpperCase()} · ${r.w}×${r.h} · ${r.fps}${r.df ? ' DF' : ''} fps · ${r.project}`;
        $('#status').className = 'status ok';
        App.emit('status', r);
      } else {
        $('#status').textContent = (r && r.error) || 'Not connected';
        $('#status').className = 'status bad';
      }
    } catch (e) { $('#status').textContent = 'Not connected'; $('#status').className = 'status bad'; }
  }
  await poll();
  setInterval(poll, 2000);


  const lp = $('#logpanel');
  const loadLog = async () => { const r = await window.tf.getLog(); $('#logtext').value = (r && r.text) || ''; $('#logtext').scrollTop = 1e9; };
  $('#logbtn').addEventListener('click', () => { lp.hidden = !lp.hidden; $('#logbtn').textContent = lp.hidden ? 'Log ▴' : 'Log ▾'; if (!lp.hidden) loadLog(); });
  $('#log-refresh').addEventListener('click', loadLog);
  $('#log-clear').addEventListener('click', async () => { await window.tf.clearLog(); loadLog(); });
  $('#log-copy').addEventListener('click', async () => {
    const t = $('#logtext');
    try { await navigator.clipboard.writeText(t.value); } catch (_) { t.select(); document.execCommand('copy'); }
    App.msg('Log copied. Paste it to Claude with your bug report.', 'ok');
  });

  let tab = 'titles';
  try { tab = localStorage.getItem('tf-tab') || 'titles'; } catch (_) {}
  App.showTab(tab);
  App.log('UI started');
})();
