// Core helpers shared by all tabs.
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const App = {
  status: null,
  handlers: {},
  custom: [],
  on(e, f) { (this.handlers[e] = this.handlers[e] || []).push(f); return f; },
  emit(e, d) { (this.handlers[e] || []).forEach((f) => { try { f(d); } catch (err) { App.log('handler error ' + e + ': ' + err.message); } }); },
  aspect() { return 9 / 16; }, // reel-only: always 1080x1920
  styles() { return TF.STYLES.concat(this.custom); },
  style(id) { return this.styles().find((s) => s.id === id) || TF.STYLES[1]; },
  saveCustom() { try { localStorage.setItem('tf-custom', JSON.stringify(this.custom)); } catch (_) {} },
  tc(frames) { const s = this.status; return s ? TF.framesToTC(frames, s.fps, s.df) : String(frames); },
  log(s) { try { window.tf.addLog(s); } catch (_) {} },
  msg(text, kind) { const m = $('#msg'); m.textContent = text || ''; m.className = 'msg ' + (kind || ''); },
  async call(name, arg) {
    try {
      const r = await window.tf[name](arg);
      if (r && r.ok === false) App.msg(r.error, 'err');
      return r || { ok: false, error: 'No response' };
    } catch (e) {
      const m = String((e && e.message) || e);
      App.msg(m, 'err'); App.log(name + ' threw: ' + m);
      return { ok: false, error: m };
    }
  },
  setAspect(el) { el.style.aspectRatio = String(App.aspect()); },
  showTab(name) {
    $$('.tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
    $$('.pane').forEach((p) => p.classList.toggle('active', p.id === 'pane-' + name));
    document.body.dataset.tab = name;
    try { localStorage.setItem('tf-tab', name); } catch (_) {}
    App.emit('show:' + name);
  },
};
try { App.custom = JSON.parse(localStorage.getItem('tf-custom') || '[]'); } catch (_) { App.custom = []; }

// generic widgets
function seg(root, get, set) {
  const paint = () => $$('button', root).forEach((b) => b.classList.toggle('on', String(b.dataset.v) === String(get())));
  $$('button', root).forEach((b) => b.addEventListener('click', () => { set(b.dataset.v); paint(); }));
  paint();
  return paint;
}
function slider(input, label, fmt, onInput) {
  const upd = () => { if (label) label.textContent = fmt(parseFloat(input.value)); };
  input.addEventListener('input', () => { upd(); if (onInput) onInput(parseFloat(input.value)); });
  upd();
  return upd;
}

window.addEventListener('error', (e) => App.log(`JS error: ${e.message} @${(e.filename || '').split('/').pop()}:${e.lineno}`));
window.addEventListener('unhandledrejection', (e) => App.log('Unhandled promise rejection: ' + (e.reason && e.reason.message || e.reason)));

// ---------- SVG icons (stroke style, match the reference tool) ----------
const IC = (d, extra) => `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra || ''}>${d}</svg>`;
const ICONS = {
  alignL: IC('<path d="M4 4v16"/><rect x="8" y="6" width="12" height="4" rx="1" fill="currentColor"/><rect x="8" y="14" width="7" height="4" rx="1" fill="currentColor"/>'),
  alignC: IC('<path d="M12 3v18"/><rect x="5" y="6" width="14" height="4" rx="1" fill="currentColor"/><rect x="8" y="14" width="8" height="4" rx="1" fill="currentColor"/>'),
  alignR: IC('<path d="M20 4v16"/><rect x="4" y="6" width="12" height="4" rx="1" fill="currentColor"/><rect x="9" y="14" width="7" height="4" rx="1" fill="currentColor"/>'),
  dup: IC('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>'),
  copy: IC('<path d="M5 19l4-1 9-9-3-3-9 9z"/><path d="M13 7l3 3"/>'),
  paste: IC('<rect x="8" y="3" width="8" height="4" rx="1"/><path d="M16 5h2a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2"/>'),
  center: IC('<circle cx="12" cy="12" r="3"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5"/>'),
  size: IC('<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>'),
  style: IC('<circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r="1" fill="currentColor"/><circle cx="15" cy="10" r="1" fill="currentColor"/><path d="M8.5 15c2 2 5 2 7 0"/>'),
  font: '<b style="font-size:13px;letter-spacing:-.02em">Aa</b>',
  del: IC('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  all: IC('<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor"/>'),
  video: IC('<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="9" y="10" width="6" height="4" fill="currentColor"/>'),
  reset: IC('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>'),
  play: IC('<path d="M7 5l12 7-12 7z" fill="currentColor"/>'),
  undo: IC('<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>'),
  redo: IC('<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>'),
  t1: IC('<rect x="9" y="4" width="6" height="3" rx=".8" fill="currentColor"/><rect x="4" y="10.5" width="16" height="4" rx=".8" fill="currentColor"/><rect x="9" y="18" width="6" height="3" rx=".8" fill="currentColor"/>', 'width="22" height="22"'),
  t2: IC('<rect x="3" y="9" width="5" height="6" rx="1" fill="currentColor"/><rect x="9.5" y="9" width="5" height="6" rx="1" fill="currentColor"/><rect x="16" y="9" width="5" height="6" rx="1" fill="currentColor"/>', 'width="22" height="22"'),
  t3: IC('<rect x="6" y="3" width="12" height="5" rx="1" fill="currentColor"/><rect x="6" y="9.5" width="12" height="5" rx="1" fill="currentColor"/><rect x="6" y="16" width="12" height="5" rx="1" fill="currentColor"/>', 'width="22" height="22"'),
  shake: IC('<path d="M3 12h3l2-6 3 12 3-12 2 6h5"/>'),
  jitter: IC('<rect x="4" y="7" width="13" height="13" rx="2"/><path d="M8 4h10a2 2 0 0 1 2 2v10"/>'),
  scribble: IC('<path d="M3 15c2-4 3-4 4 0s2 4 4 0 2-4 3 0 2 4 4 0 2-3 3-1"/>'),
  mblur: IC('<circle cx="17" cy="12" r="3.5" fill="currentColor"/><path d="M3 9h8M5 12h8M3 15h8"/>'),
  more: IC('<circle cx="5" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="19" cy="12" r="1" fill="currentColor"/>'),
  search: IC('<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.3-4.3"/>'),
  cc: IC('<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10a2 2 0 1 0 0 4M16 10a2 2 0 1 0 0 4"/>'),
};
