const { contextBridge, ipcRenderer } = require('electron');

const call = (name) => (arg) => ipcRenderer.invoke('tf:' + name, arg);

contextBridge.exposeInMainWorld('tf', {
  status: call('status'),
  insert: call('insert'),
  titleAtPlayhead: call('titleAtPlayhead'),
  updateTitle: call('updateTitle'),
  updateRange: call('updateRange'),
  updateRangeLook: call('updateRangeLook'),
  compact: call('compact'),
  autoMatch: call('autoMatch'),
  placeWords: call('placeWords'),
  captionAtPlayhead: call('captionAtPlayhead'),
  deleteTitles: call('deleteTitles'),
  probe: call('probe'),
  frame: call('frame'),
  updateAt: call('updateAt'),
  readCaptions: call('readCaptions'),
  generateCaptions: call('generateCaptions'),
  placeCaptions: call('placeCaptions'),
  cancel: call('cancel'),
  importStyle: call('importStyle'),
  getLog: call('getLog'),
  addLog: call('addLog'),
  clearLog: call('clearLog'),
  onProgress: (cb) => ipcRenderer.on('tf:progress', (_e, d) => cb(d)),
});
