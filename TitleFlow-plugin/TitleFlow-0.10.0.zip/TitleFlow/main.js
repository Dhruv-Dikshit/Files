const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');
const TF = require('./lib/shared');
const store = require('./lib/store');
const { patchComp } = require('./lib/textplus');

// WorkflowIntegration.node ships with DaVinci Resolve (see INSTALL.md).
const WorkflowIntegration = require('./WorkflowIntegration.node');
const PLUGIN_ID = 'com.dhruv.titleflow';

let win = null;
let cancelFlag = false;

// ---------------- logging ----------------
const logs = [];
const LOGFILE = path.join(os.homedir(), 'TitleFlow_log.txt');
function log(...a) {
  const line = `[${new Date().toTimeString().slice(0, 8)}] ` + a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ');
  logs.push(line); if (logs.length > 500) logs.shift();
  try { fs.appendFileSync(LOGFILE, line + '\n'); } catch (_) {}
}

// ---------------- Resolve access ----------------
let resolve = null;
async function getResolve() {
  if (resolve) return resolve;
  const ok = await WorkflowIntegration.Initialize(PLUGIN_ID);
  if (!ok) throw new Error('Could not connect to Resolve. Workflow Integrations need DaVinci Resolve Studio.');
  resolve = await WorkflowIntegration.GetResolve();
  if (!resolve) throw new Error('Connected, but Resolve returned no API object.');
  log('connected to Resolve', await resolve.GetVersionString());
  return resolve;
}

async function ctx() {
  const r = await getResolve();
  const pm = await r.GetProjectManager();
  const project = await pm.GetCurrentProject();
  if (!project) throw new Error('No project is open.');
  const timeline = await project.GetCurrentTimeline();
  if (!timeline) throw new Error('No timeline is open.');
  const fps = parseFloat(await project.GetSetting('timelineFrameRate')) || 24;
  const df = String(await project.GetSetting('timelineDropFrameTimecode')) === '1';
  const w = parseInt(await project.GetSetting('timelineResolutionWidth'), 10) || 1920;
  const h = parseInt(await project.GetSetting('timelineResolutionHeight'), 10) || 1080;
  return { project, timeline, fps, df, w, h, pname: await project.GetName(), tname: await timeline.GetName() };
}

const toTC = (c, f) => TF.framesToTC(f, c.fps, c.df);

async function readInOut(timeline) {
  if (typeof timeline.GetMarkInOut !== 'function') return null;
  const m = await timeline.GetMarkInOut();
  if (m && m.video && m.video.in !== undefined && m.video.out !== undefined) return { in: Number(m.video.in), out: Number(m.video.out) };
  return null;
}
async function playheadFrame(c) { return TF.tcToFrames(await c.timeline.GetCurrentTimecode(), c.fps); }

// Lock every track except the target video track so an insert edit never cuts or shifts other tracks.
async function lockOthers(c, target) {
  const tl = c.timeline;
  const locked = [];
  let vCount = Number(await tl.GetTrackCount('video'));
  while (vCount < target) { await tl.AddTrack('video'); vCount++; }
  for (const type of ['video', 'audio', 'subtitle']) {
    let n = 0;
    try { n = Number(await tl.GetTrackCount(type)); } catch (_) { continue; }
    for (let i = 1; i <= n; i++) {
      if (type === 'video' && i === target) continue;
      try {
        if (!(await tl.GetIsTrackLocked(type, i))) { await tl.SetTrackLock(type, i, true); locked.push([type, i]); }
      } catch (_) {}
    }
  }
  return async () => { for (const [t, i] of locked) { try { await tl.SetTrackLock(t, i, false); } catch (_) {} } };
}

// ---------------- destination track ----------------
// Resolve inserts titles on the timeline's destination track, and the scripting API cannot change it.
// The Edit page shortcut Option+1..8 sets the video destination to V1..V8, so we bring Resolve to the
// front and press it (macOS asks once to allow TitleFlow/Electron under Privacy & Security > Accessibility).
const DIGIT_KEYCODES = { 1: 18, 2: 19, 3: 20, 4: 21, 5: 23, 6: 22, 7: 26, 8: 28 };
let destWarned = false;
function osa(lines) {
  return new Promise((res) => execFile('osascript', lines.flatMap((l) => ['-e', l]), { timeout: 5000 }, (err, out, errOut) => res(err ? String(errOut || err.message) : null)));
}
async function setDestination(track) {
  if (process.platform !== 'darwin' || !DIGIT_KEYCODES[track]) return `V${track} can't be targeted (only V1-V8 on macOS)`;
  const err = await osa([
    'tell application "DaVinci Resolve" to activate',
    'delay 0.25',
    `tell application "System Events" to key code ${DIGIT_KEYCODES[track]} using {option down}`,
    'delay 0.15',
  ]);
  if (err) {
    log('could not set destination track V' + track + ':', err.trim());
    if (!destWarned) { destWarned = true; return 'TitleFlow could not press Option+' + track + ' in Resolve. Allow it in System Settings > Privacy & Security > Accessibility (enable TitleFlow / Electron), then try again.'; }
    return 'could not set destination';
  }
  return null;
}
function refocus() { try { if (win) { app.focus({ steal: true }); win.focus(); } } catch (_) {} }

// ---------------- scanning titles we placed ----------------
async function scanTitles(c) {
  const data = store.forTimeline(c.pname, c.tname);
  const out = [];
  const n = Number(await c.timeline.GetTrackCount('video'));
  for (let t = 1; t <= n; t++) {
    const items = (await c.timeline.GetItemListInTrack('video', t)) || [];
    for (const it of items) {
      const uid = await it.GetUniqueId();
      if (data[uid]) out.push({ uid, item: it, entry: data[uid], model: data[uid].model, start: Number(await it.GetStart()), end: Number(await it.GetEnd()), track: t });
    }
  }
  return out.sort((a, b) => a.start - b.start);
}

// ---------------- writing a model into a timeline item ----------------
async function applyModel(c, item, model) {
  // Keep Resolve's own Text+ and only change its settings: export the clip's comp, patch the Text+, import it back.
  const seed = TF.hash(model.blocks.map((b) => b.text).join('|'));
  const names = (await item.GetFusionCompNameList()) || [];
  const idx = Math.max(1, names.length);
  const stamp = Date.now();
  const src = path.join(os.tmpdir(), `titleflow_src_${stamp}.comp`);
  const ok = await item.ExportFusionComp(src, idx);
  if (!ok || !fs.existsSync(src)) { log('export of the Text+ comp failed', ok); return 'failed'; }
  let comp;
  try { comp = patchComp(fs.readFileSync(src, 'utf8'), model, { w: c.w, h: c.h, aspect: c.w / c.h, seed, tag: stamp }); }
  catch (e) { log('patch failed:', String(e.message || e)); try { fs.copyFileSync(src, path.join(os.homedir(), 'TitleFlow_source.comp')); } catch (_) {} return 'failed'; }
  try { fs.writeFileSync(path.join(os.homedir(), 'TitleFlow_last.comp'), comp); } catch (_) {}
  const file = path.join(os.tmpdir(), `titleflow_${stamp}.comp`);
  fs.writeFileSync(file, comp);

  const imported = await item.ImportFusionComp(file);
  const after = (await item.GetFusionCompNameList()) || [];
  log('import', imported ? 'ok' : 'FALSE', 'comps before', names, 'after', after);
  // use the newest comp, then check it really holds our text by exporting it again
  const n = Math.max(1, after.length);
  if (after.length > names.length) { try { await item.LoadFusionCompByName(after[n - 1]); } catch (_) {} }
  const chk = path.join(os.tmpdir(), `titleflow_chk_${stamp}.comp`);
  let good = false;
  try { if (await item.ExportFusionComp(chk, n)) good = fs.readFileSync(chk, 'utf8').includes('tf_tag=' + stamp); } catch (_) {}
  log('verify: Text+ settings', good ? 'applied' : 'NOT found in the clip comp');
  if (good && after.length > names.length && after.filter((x) => x === after[n - 1]).length === 1) {
    for (const x of names) { if (x !== after[n - 1]) { try { await item.DeleteFusionCompByName(x); } catch (_) {} } }
  }
  for (const f of [src, file, chk]) { try { fs.unlinkSync(f); } catch (_) {} }
  return good ? 'animated' : 'failed';
}

// ---------------- placing ----------------
async function snapKeys(c) {
  const set = new Set();
  const n = Number(await c.timeline.GetTrackCount('video')) || 0;
  for (let t = 1; t <= n; t++) {
    for (const x of (await c.timeline.GetItemListInTrack('video', t)) || []) {
      try { set.add(t + ':' + Number(await x.GetStart()) + ':' + Number(await x.GetEnd())); } catch (_) {}
    }
  }
  return set;
}
async function findNewItem(c, before, prefTrack) {
  const n = Number(await c.timeline.GetTrackCount('video')) || 0;
  const order = [prefTrack]; for (let t = n; t >= 1; t--) if (t !== prefTrack) order.push(t);
  for (const t of order) {
    for (const x of (await c.timeline.GetItemListInTrack('video', t)) || []) {
      try { if (!before.has(t + ':' + Number(await x.GetStart()) + ':' + Number(await x.GetEnd()))) return x; } catch (_) {}
    }
  }
  return null;
}

async function placeOne(c, o) {
  const model = TF.clone(o.model);
  const ph = o.startFrame != null ? o.startFrame : await playheadFrame(c);
  if (o.matchPrev) {
    const prev = (await scanTitles(c)).filter((t) => t.start < ph).pop();
    if (prev && model.anim.in.slide && prev.model.anim.out.slide) { model.anim.in.dir = prev.model.anim.out.dir; log('entry matched to previous exit:', model.anim.in.dir); }
  }
  if (o.dur) model.dur = Math.round(o.dur);
  // Inserting titles only works on the Edit page (it fails on Cut, Fusion, Color...), so switch there first.
  try { const r = await getResolve(); if ((await r.GetCurrentPage()) !== 'edit') { await r.OpenPage('edit'); log('switched to the Edit page'); } } catch (e) { log('could not switch to the Edit page:', String(e.message || e)); }
  if (o.startFrame != null) await c.timeline.SetCurrentTimecode(toTC(c, o.startFrame));
  const before = await snapKeys(c);
  const ret = await c.timeline.InsertFusionTitleIntoTimeline('Text+');
  if (!ret) throw new Error('Resolve could not insert a Text+ title at the playhead. Check that the Edit page is open and that the timeline destination track (the red V patch) points at an unlocked video track.');
  // The handle returned by the insert call can be stale in Resolve 21 ("Unable to find proxy object"),
  // so find the new clip by scanning the timeline for the item that was not there before.
  let item = ret;
  try { await ret.GetUniqueId(); } catch (e) {
    log('returned handle stale, scanning timeline:', String(e.message || e));
    item = await findNewItem(c, before, o.track);
    if (!item) throw new Error('Inserted the title but could not find it on the timeline.');
  }
  const uid = await item.GetUniqueId();
  const start = Number(await item.GetStart()), end = Number(await item.GetEnd());
  let warning = null, landed = o.track;
  try {
    const ti = await item.GetTrackTypeAndIndex();
    if (ti) landed = Number(ti[1]);
    if (landed !== o.track) { warning = `A word landed on V${landed} instead of V${o.track}. Check that Option+${o.track} sets the destination track in Resolve.`; log('landed on V' + landed, 'wanted V' + o.track); }
  } catch (_) {}
  const mode = await applyModel(c, item, model);
  store.put(c.pname, c.tname, uid, { model, start, end, track: o.track });
  log('placed', uid, 'start', start, 'mode', mode);
  return { uid, start, end, mode, warning, model, landed };
}

async function insert(o) {
  const c = await ctx();
  const track = Math.max(1, Math.round(o.track || 2));
  let startFrame = null, dur = o.dur || null;
  if (o.mode === 'inout') {
    const io = await readInOut(c.timeline);
    if (!io) throw new Error('No In/Out marks set on the timeline (press I and O).');
    startFrame = io.in; dur = Math.max(6, io.out - io.in);
  } else if (o.seconds) dur = Math.round(o.seconds * c.fps);
  const unlock = await lockOthers(c, track);
  const dw = await setDestination(track);
  try {
    const r = await placeOne(c, { model: o.model, startFrame, dur, track, matchPrev: o.matchPrev });
    if (dw && !r.warning) r.warning = dw;
    return { ok: true, uid: r.uid, mode: r.mode, warning: r.warning, model: r.model };
  } finally { await unlock(); refocus(); }
}

// ---------------- editing existing titles ----------------
async function titleAtPlayhead() {
  const c = await ctx();
  const ph = await playheadFrame(c);
  const all = await scanTitles(c);
  const hits = all.filter((t) => t.start <= ph && ph < t.end).sort((a, b) => b.track - a.track);
  const t = hits[0];
  if (!t) return { ok: true, none: true };
  const idx = all.indexOf(t);
  return { ok: true, uid: t.uid, model: t.model, start: t.start, end: t.end, track: t.track, tc: toTC(c, t.start), hasPrev: idx > 0, hasNext: idx < all.length - 1 };
}

async function updateTitle(o) {
  const c = await ctx();
  const t = (await scanTitles(c)).find((x) => x.uid === o.uid);
  if (!t) throw new Error('That title is no longer on the timeline.');
  const model = TF.clone(o.model);
  if (!model.dur && t.model.dur) model.dur = t.model.dur;
  const mode = await applyModel(c, t.item, model);
  store.put(c.pname, c.tname, t.uid, { model, start: t.start, end: t.end, track: t.track });
  return { ok: true, mode };
}

async function updateRange(o) {
  const c = await ctx();
  const io = await readInOut(c.timeline);
  if (!io) throw new Error('Set In/Out marks (I and O) to apply to a range.');
  const hits = (await scanTitles(c)).filter((t) => t.end > io.in && t.start < io.out);
  for (const t of hits) {
    const model = TF.clone(t.model); model.anim = TF.clone(o.anim);
    await applyModel(c, t.item, model);
    store.put(c.pname, c.tname, t.uid, { model, start: t.start, end: t.end, track: t.track });
  }
  log('updated range', hits.length, 'titles');
  return { ok: true, count: hits.length };
}

async function autoMatch(o) {
  const c = await ctx();
  const all = await scanTitles(c);
  const i = all.findIndex((x) => x.uid === o.uid);
  if (i < 0) throw new Error('Select a TitleFlow title under the playhead first.');
  const cur = all[i], prev = all[i - 1], next = all[i + 1];
  const updated = [];
  const m = TF.clone(cur.model);
  if (prev && m.anim.in.slide) m.anim.in.dir = prev.model.anim.out.dir;
  const pos = (md) => { const bb = TF.bbox(md.blocks, c.w / c.h); return [bb.cx, bb.cy]; };
  if (next) {
    const a = pos(m), b = pos(next.model);
    const dx = b[0] - a[0], dy = b[1] - a[1];
    let dir = m.anim.in.dir;
    if (Math.abs(dy) >= Math.abs(dx) && Math.abs(dy) > 0.02) dir = dy > 0 ? 'up' : 'down';
    else if (Math.abs(dx) > 0.02) dir = dx > 0 ? 'right' : 'left';
    m.anim.out.slide = true; m.anim.out.dir = dir;
    const n = TF.clone(next.model);
    if (n.anim.in.slide) n.anim.in.dir = dir;
    updated.push({ uid: next.uid, model: n, item: next });
  }
  updated.unshift({ uid: cur.uid, model: m, item: cur });
  for (const u of updated) {
    await applyModel(c, u.item.item, u.model);
    store.put(c.pname, c.tname, u.uid, { model: u.model, start: u.item.start, end: u.item.end, track: u.item.track });
  }
  log('auto-match updated', updated.length, 'titles');
  return { ok: true, updated: updated.map((u) => ({ uid: u.uid, model: u.model })) };
}

async function updateAt(o) {
  const c = await ctx();
  const all = await scanTitles(c);
  const t = all.find((x) => Math.abs(x.start - o.start) <= 1 && (!o.track || x.track === o.track)) || all.find((x) => Math.abs(x.start - o.start) <= 2);
  if (!t) return { ok: true, found: false };
  const model = TF.clone(o.model);
  const mode = await applyModel(c, t.item, model);
  store.put(c.pname, c.tname, t.uid, { model, start: t.start, end: t.end, track: t.track });
  return { ok: true, found: true, mode };
}

// ---------------- per-word layers ----------------
// Keeps exactly one video track unlocked at a time (all other tracks locked) so an insert never cuts or shifts anything else.
async function lockManager(c, maxTrack) {
  const tl = c.timeline;
  let vCount = Number(await tl.GetTrackCount('video'));
  while (vCount < maxTrack) { await tl.AddTrack('video'); vCount++; }
  const orig = [];
  const all = [];
  for (const type of ['video', 'audio', 'subtitle']) {
    let n = 0;
    try { n = Number(await tl.GetTrackCount(type)); } catch (_) { continue; }
    for (let i = 1; i <= n; i++) {
      let was = false;
      try { was = !!(await tl.GetIsTrackLocked(type, i)); } catch (_) {}
      orig.push([type, i, was]); all.push([type, i]);
    }
  }
  const state = new Map();
  const set = async (type, i, lock) => {
    const k = type + i;
    if (state.get(k) === lock) return;
    try { await tl.SetTrackLock(type, i, lock); state.set(k, lock); } catch (_) {}
  };
  for (const [type, i, was] of orig) state.set(type + i, was);
  return {
    async only(track) { for (const [type, i] of all) await set(type, i, !(type === 'video' && i === track)); },
    async restore() { for (const [type, i, was] of orig) await set(type, i, was); },
  };
}

async function placeWords(o) {
  const c = await ctx();
  cancelFlag = false;
  const items = o.items.slice().sort((a, b) => a.start - b.start || a.track - b.track);
  const maxTrack = items.reduce((m, it) => Math.max(m, it.track), 1);
  const lm = await lockManager(c, maxTrack);
  let done = 0, failed = 0, firstWarning = null;
  try {
    for (let i = 0; i < items.length; i++) {
      if (cancelFlag) { log('placing cancelled at', i); break; }
      const it = items[i];
      try {
        await lm.only(it.track);
        const dw = await setDestination(it.track);
        if (dw && !firstWarning) firstWarning = dw;
        const r = await placeOne(c, { model: it.model, startFrame: it.start, dur: Math.max(4, it.end - it.start), track: it.track, matchPrev: false });
        if (r.mode === 'failed') failed++;
        if (r.warning && !firstWarning) firstWarning = r.warning;
        // trim: a temp title at the wanted end splits our clip exactly there; then remove everything on this track from that point on
        if (r.end < it.end - 1) {
          const have = ((r.end - r.start) / c.fps).toFixed(1), want = ((it.end - it.start) / c.fps).toFixed(1);
          if (!firstWarning) firstWarning = `Resolve's Text+ clip is only ${have}s but ${want}s was asked. Set Preferences > User > Editing > Standard Generator Duration to 7 seconds once, then try again.`;
          log('clip shorter than requested', have, 'vs', want);
        }
        if (r.end > it.end) {
          await c.timeline.SetCurrentTimecode(toTC(c, it.end));
          const tmp = await c.timeline.InsertFusionTitleIntoTimeline('Text+'); // handle may be stale; only used as a flag
          const junk = [];
          for (const x of (await c.timeline.GetItemListInTrack('video', it.track)) || []) {
            if (Number(await x.GetStart()) >= it.end) junk.push(x);
          }
          if (junk.length) log('trim: removed', junk.length, 'piece(s)', await c.timeline.DeleteClips(junk, false), tmp ? '' : '(temp insert returned nothing)');
        }
        done++;
      } catch (e) { failed++; log('word', i, 'failed:', String(e.message || e)); }
      if (win) win.webContents.send('tf:progress', { i: i + 1, n: items.length });
    }
  } finally { await lm.restore(); refocus(); }
  return { ok: true, done, failed, warning: firstWarning, cancelled: cancelFlag };
}

async function deleteTitles(o) {
  const c = await ctx();
  const hit = (await scanTitles(c)).filter((t) => (o.uids || []).includes(t.uid));
  if (!hit.length) return { ok: true, count: 0 };
  const ok = await c.timeline.DeleteClips(hit.map((t) => t.item), false);
  hit.forEach((t) => { try { store.remove(c.pname, c.tname, t.uid); } catch (_) {} });
  log('deleted titles', hit.length, ok);
  return { ok: true, count: hit.length };
}

async function captionAtPlayhead() {
  const c = await ctx();
  const ph = await playheadFrame(c);
  const all = await scanTitles(c);
  const parts = all.filter((t) => t.start <= ph && ph < t.end).sort((a, b) => a.track - b.track || a.start - b.start);
  if (!parts.length) return { ok: true, none: true };
  return { ok: true, parts: parts.map((t) => ({ uid: t.uid, model: t.model, track: t.track, start: t.start, end: t.end })), tc: toTC(c, parts[0].start) };
}

async function probe() {
  const c = await ctx();
  const ph = await playheadFrame(c);
  const out = [];
  const L = (...a) => { log('[probe]', ...a); out.push(a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')); };
  L('Resolve version', await (await getResolve()).GetVersionString());
  let item = null, trackIdx = 0;
  const n = Number(await c.timeline.GetTrackCount('video')) || 0;
  for (let t = n; t >= 1 && !item; t--) {
    for (const it of (await c.timeline.GetItemListInTrack('video', t)) || []) {
      if (Number(await it.GetStart()) <= ph && ph < Number(await it.GetEnd())) { item = it; trackIdx = t; break; }
    }
  }
  if (!item) { L('No clip under the playhead. Park it on a Text+ title and run again.'); return { ok: true, lines: out }; }
  L('clip', await item.GetName(), 'track', trackIdx);
  const methods = ['SetProperty', 'GetProperty', 'AddKeyframe', 'SetKeyframe', 'GetKeyframes', 'DeleteKeyframe', 'SetKeyframes', 'GetFusionCompCount', 'GetFusionCompNameList', 'GetFusionCompByIndex', 'ImportFusionComp', 'ExportFusionComp', 'AddFusionComp', 'LoadFusionCompByName', 'SetClipEnabled', 'ApplyArriCdlLut'];
  L('methods', methods.map((m) => m + ':' + (typeof item[m] === 'function' ? 'yes' : 'no')).join(' '));
  try { L('own+proto names', Object.getOwnPropertyNames(Object.getPrototypeOf(item) || {}).slice(0, 120).join(',')); } catch (e) { L('enumerate failed', String(e.message || e)); }
  try { L('GetProperty()', await item.GetProperty()); } catch (e) { L('GetProperty failed', String(e.message || e)); }
  for (const k of ['Pan', 'Tilt', 'ZoomX', 'ZoomY', 'Opacity', 'RotationAngle', 'CompositeMode']) { try { L('prop', k, await item.GetProperty(k)); } catch (e) { L('prop', k, 'failed'); } }
  try {
    const before = await item.GetProperty('Pan');
    const ok = await item.SetProperty('Pan', 12.5); L('SetProperty Pan 12.5 ->', ok, 'now', await item.GetProperty('Pan'));
    await item.SetProperty('Pan', before);
  } catch (e) { L('SetProperty test failed', String(e.message || e)); }
  try {
    L('fusion comps', await item.GetFusionCompNameList());
    const comp = await item.GetFusionCompByIndex(1);
    if (comp) {
      L('comp methods', ['GetToolList', 'FindTool', 'AddTool', 'CurrentTime', 'SetAttrs', 'GetAttrs', 'Lock', 'StartUndo'].map((m) => m + ':' + (typeof comp[m] === 'function' ? 'yes' : 'no')).join(' '));
      if (typeof comp.GetToolList === 'function') {
        const tl = await comp.GetToolList(false);
        const names = [];
        for (const k of Object.keys(tl || {})) { const t = tl[k]; try { names.push(k + ':' + (await t.GetAttrs()).TOOLS_RegID); } catch (_) { names.push(k); } }
        L('tools in comp', names.join(', '));
      }
    }
  } catch (e) { L('fusion probe failed', String(e.message || e)); }
  try { L('comp text of first comp saved to ~/TitleFlow_probe.comp'); const f = path.join(os.homedir(), 'TitleFlow_probe.comp'); if (typeof item.ExportFusionComp === 'function') L('export', await item.ExportFusionComp(f, 1)); } catch (e) { L('export failed', String(e.message || e)); }
  return { ok: true, lines: out };
}

async function frame() {
  const c = await ctx();
  if (typeof c.project.ExportCurrentFrameAsStill !== 'function') return { ok: true, warning: 'This Resolve version cannot export the current frame.' };
  const f = path.join(os.tmpdir(), 'titleflow_frame_' + Date.now() + '.jpg');
  const ok = await c.project.ExportCurrentFrameAsStill(f);
  log('ExportCurrentFrameAsStill', ok, f);
  const real = [f, f.replace(/\.jpg$/, '') + '.jpg', f + '.jpg'].find((p) => fs.existsSync(p));
  if (!ok || !real) return { ok: true, warning: 'Resolve did not export a frame (open the Color or Edit page and try again).' };
  const buf = fs.readFileSync(real);
  try { fs.unlinkSync(real); } catch (_) {}
  return { ok: true, dataUrl: 'data:image/jpeg;base64,' + buf.toString('base64') };
}

// ---------------- captions ----------------
async function readCaptions(o) {
  const c = await ctx();
  const io = await readInOut(c.timeline);
  let n = 0;
  try { n = Number(await c.timeline.GetTrackCount('subtitle')); } catch (_) {}
  const base = { ok: true, fps: c.fps, df: c.df, inOut: io, hasSubtitles: n > 0 };
  if (!n) return Object.assign(base, { words: [] });
  const items = (await c.timeline.GetItemListInTrack('subtitle', 1)) || [];
  const words = [];
  for (const it of items) {
    const text = String((await it.GetName()) || '').trim();
    const s = Number(await it.GetStart()), e = Number(await it.GetEnd());
    const ws = text.split(/\s+/).filter(Boolean);
    if (!ws.length) continue;
    const total = ws.reduce((a, w) => a + w.length, 0) || 1;
    let cur = s;
    ws.forEach((w) => {
      const d = ((e - s) * w.length) / total;
      words.push({ word: w, start: Math.round(cur), end: Math.round(cur + d) });
      cur += d;
    });
  }
  const filtered = o && o.useInOut && io ? words.filter((w) => w.end > io.in && w.start < io.out) : words;
  log('read captions', items.length, 'subtitle items ->', filtered.length, 'words');
  return Object.assign(base, { words: filtered });
}

async function generateCaptions() {
  const c = await ctx();
  if (typeof c.timeline.CreateSubtitlesFromAudio !== 'function') throw new Error('This Resolve version cannot create subtitles from the API. In Resolve use Timeline > Create Subtitles from Audio, then press Read.');
  // one subtitle per word (max 1 character per line, single line, no gap) gives real per-word timing
  let ok = false;
  try {
    const R = await getResolve();
    const cfg = {};
    if (R.SUBTITLE_LANGUAGE !== undefined) cfg[R.SUBTITLE_LANGUAGE] = R.AUTO_CAPTION_AUTO;
    if (R.SUBTITLE_CAPTION_PRESET !== undefined) cfg[R.SUBTITLE_CAPTION_PRESET] = R.AUTO_CAPTION_SUBTITLE_DEFAULT;
    if (R.SUBTITLE_CHARS_PER_LINE !== undefined) cfg[R.SUBTITLE_CHARS_PER_LINE] = 1;
    if (R.SUBTITLE_LINE_BREAK !== undefined) cfg[R.SUBTITLE_LINE_BREAK] = R.AUTO_CAPTION_LINE_SINGLE;
    if (R.SUBTITLE_GAP !== undefined) cfg[R.SUBTITLE_GAP] = 0;
    log('CreateSubtitlesFromAudio settings keys', Object.keys(cfg).length);
    ok = Object.keys(cfg).length ? await c.timeline.CreateSubtitlesFromAudio(cfg) : await c.timeline.CreateSubtitlesFromAudio();
  } catch (e) { log('CreateSubtitlesFromAudio with settings failed:', String(e.message || e)); }
  if (!ok) ok = await c.timeline.CreateSubtitlesFromAudio();
  log('CreateSubtitlesFromAudio', ok);
  if (!ok) throw new Error('Resolve did not create subtitles. Try Timeline > Create Subtitles from Audio manually.');
  return { ok: true };
}

async function placeCaptions(o) {
  const c = await ctx();
  const track = Math.max(1, Math.round(o.track || 2));
  cancelFlag = false;
  const unlock = await lockOthers(c, track);
  const dw = await setDestination(track);
  const expected = new Set(o.items.map((it) => it.start));
  const beforeUids = new Set();
  for (const it of (await c.timeline.GetItemListInTrack('video', track)) || []) beforeUids.add(await it.GetUniqueId());
  let done = 0, failed = 0, firstWarning = dw;
  try {
    for (let i = 0; i < o.items.length; i++) {
      if (cancelFlag) { log('placing cancelled at', i); break; }
      const it = o.items[i];
      try {
        const r = await placeOne(c, { model: it.model, startFrame: it.start, dur: Math.max(6, it.end - it.start), track, matchPrev: false });
        if (r.mode === 'failed') failed++;
        if (r.warning && !firstWarning) firstWarning = r.warning;
        done++;
      } catch (e) { failed++; log('caption', i, 'failed:', String(e.message || e)); }
      if (win) win.webContents.send('tf:progress', { i: i + 1, n: o.items.length });
    }
    // Each insert splits the previous title (trimming it exactly), leaving a leftover right-hand piece. Remove those.
    try {
      const junk = [];
      for (const it of (await c.timeline.GetItemListInTrack('video', track)) || []) {
        const uid = await it.GetUniqueId();
        if (beforeUids.has(uid)) continue;
        if (!expected.has(Number(await it.GetStart()))) junk.push(it);
      }
      if (junk.length) { const okDel = await c.timeline.DeleteClips(junk, false); log('removed leftover pieces', junk.length, okDel); }
    } catch (e) { log('cleanup failed', String(e.message || e)); }
  } finally { await unlock(); refocus(); }
  return { ok: true, done, failed, warning: firstWarning, cancelled: cancelFlag };
}

// ---------------- styles import ----------------
async function importStyle() {
  const r = await dialog.showOpenDialog(win, { title: 'Import TitleFlow style', filters: [{ name: 'Style JSON', extensions: ['json'] }], properties: ['openFile'] });
  if (r.canceled || !r.filePaths.length) return { ok: true, styles: [] };
  const data = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
  return { ok: true, styles: Array.isArray(data) ? data : [data] };
}

// ---------------- IPC ----------------
function wrap(name, fn) {
  ipcMain.handle('tf:' + name, async (_e, arg) => {
    try { return await fn(arg); } catch (err) {
      const msg = String((err && err.message) || err);
      log(name, 'ERROR:', msg);
      return { ok: false, error: msg };
    }
  });
}
wrap('status', async () => {
  const c = await ctx();
  return { ok: true, project: c.pname, timeline: c.tname, fps: c.fps, df: c.df, w: c.w, h: c.h, inOut: await readInOut(c.timeline), playhead: await playheadFrame(c) };
});
wrap('insert', insert);
wrap('titleAtPlayhead', titleAtPlayhead);
wrap('updateTitle', updateTitle);
wrap('updateRange', updateRange);
wrap('autoMatch', autoMatch);
wrap('placeWords', placeWords);
wrap('captionAtPlayhead', captionAtPlayhead);
wrap('deleteTitles', deleteTitles);
wrap('probe', probe);
wrap('frame', frame);
wrap('updateAt', updateAt);
wrap('readCaptions', readCaptions);
wrap('generateCaptions', generateCaptions);
wrap('placeCaptions', placeCaptions);
wrap('cancel', async () => { cancelFlag = true; return { ok: true }; });
wrap('importStyle', importStyle);
wrap('getLog', async () => ({ ok: true, text: logs.join('\n') }));
wrap('addLog', async (s) => { log('[ui]', String(s)); return { ok: true }; });
wrap('clearLog', async () => { logs.length = 0; return { ok: true }; });

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 460, height: 900, minWidth: 380, backgroundColor: '#0f0f14', title: 'TitleFlow',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'index.html'));
  log('TitleFlow started');
});

app.on('window-all-closed', () => {
  try { WorkflowIntegration.CleanUp(); } catch (_) {}
  app.quit();
});
