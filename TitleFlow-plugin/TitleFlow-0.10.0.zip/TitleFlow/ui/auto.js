// AUTO tab: turn captions (subtitle track / In-Out words) into animated titles in one go.
const Auto = (() => {
  const A = {
    words: [], style: null, per: 3, punct: 'remove', mode: 'style', tpl: 1, scale: 1, look: 'style',
    cust: { slide: 70, bounce: 30, mixed: true, flicker: 0, shake: 0, blur: 0 },
    cur: 0, edits: {}, man: null, out: 'anim', track: 2, one: 'one', pasted: '', source: '', placing: false, anPlay: null,
  };
  const root = $('#pane-auto');
  const DIRKEYS = ['left', 'right', 'up', 'down'];

  root.innerHTML = `
  <div class="src-row"><span class="grow mute" id="a-info">Press Read to load captions from the timeline.</span><button class="btn" id="a-read">Read</button><button class="btn" id="a-gen" title="Timeline > Create Subtitles from Audio">Generate</button><label class="toggle small" title="Only captions inside In/Out"><input type="checkbox" id="a-io" checked><span>In/Out</span></label></div>
  <details class="paste"><summary>No captions? Paste text instead</summary>
    <textarea id="a-paste" placeholder="Paste your script. It is spread evenly over In/Out (or 10 seconds from the playhead)."></textarea>
    <button class="btn" id="a-usepaste">Use pasted text</button>
  </details>
  <label class="flbl">Style</label>
  <button class="stylecard" id="a-stylecard"><span class="thumb" id="a-thumb"></span><b id="a-sc-name"></b><span class="mute">Change ▾</span></button>
  <div class="stylelist" id="a-styles" hidden></div>
  <div class="frow"><label>Words per slide</label><span class="grow"></span><span class="mute small" id="a-per-v"></span></div>
  <div class="frow fm"><span class="mute">Fewer</span><input type="range" id="a-per" min="1" max="4" step="1" value="3"><span class="mute">More</span></div>
  <div class="frow"><label>Punctuation</label><div class="seg" id="a-punct"><button data-v="keep">Keep</button><button data-v="remove">Remove</button></div></div>
  <div class="frow"><label>Animation</label><div class="seg" id="a-mode"><button data-v="style">From style</button><button data-v="custom">Customize</button><button data-v="off">Off</button></div></div>
  <div class="frow"><label>Output</label><div class="seg" id="a-out"><button data-v="anim">Animated</button><button data-v="layout">Layouts only</button></div></div>
  <div id="a-cust" hidden>
    <div class="row"><label class="toggle"><input type="checkbox" id="c-slide" checked><span>Slide</span></label><input type="range" id="c-slide-r" min="0" max="100"><span class="val" id="c-slide-v"></span></div>
    <div class="row"><label class="toggle"><input type="checkbox" id="c-bounce"><span>Bounce</span></label><input type="range" id="c-bounce-r" min="0" max="100"><span class="val" id="c-bounce-v"></span></div>
    <div class="row"><label>Directions</label><div class="seg" id="c-dirs"><button data-v="mixed">Mixed</button><button data-v="style">From style</button></div></div>
    <div class="row"><label>Flicker</label><input type="range" id="c-flicker" min="0" max="100"><span class="val" id="c-flicker-v"></span></div>
    <div class="row"><label>Shake IN</label><input type="range" id="c-shake" min="0" max="100"><span class="val" id="c-shake-v"></span></div>
    <div class="row"><label>Blur IN</label><input type="range" id="c-blur" min="0" max="100"><span class="val" id="c-blur-v"></span></div>
  </div>
  <label class="flbl">Preview</label>
  <div class="carousel"><div class="side" id="a-prev"></div><div class="center" id="a-stage-slot"></div><div class="side" id="a-next"></div></div>
  <div class="navmid"><b id="a-i"></b><span id="a-tc" class="mute mono"></span><i class="dot" id="a-dot" hidden title="edited"></i></div>
  <div class="grip"><i></i></div>
  <div class="seg tplbig" id="a-tpl"><button data-v="1">${ICONS.t1}<span>Template 1</span></button><button data-v="2">${ICONS.t2}<span>Template 2</span></button><button data-v="3">${ICONS.t3}<span>Template 3</span></button></div>
  <div class="frow"><label>Size · all</label><input type="range" id="a-size" min="50" max="160" value="100"><span class="val" id="a-size-v"></span></div>
  <div class="frow"><label>Look · all</label><div class="seg dashed" id="a-look"><button data-v="standard">Standard</button><button data-v="style">Style</button></div></div>
  <div class="tl-row"><button class="icon" id="a-play" title="Play this slide">${ICONS.play}</button><div class="mini" id="a-mini"></div><span class="mono mute" id="a-tcnow"></span></div>
  <details class="fold"><summary>Edit this slide</summary>
    <div class="row"><label>Words</label><input id="a-edit" class="grow" placeholder="Edit this slide's words"></div>
    <div class="moves" id="a-moves"><button data-m="first-back" title="Send the first word to the previous slide">⇠ first word to previous</button><button data-m="last-fwd" title="Send the last word to the next slide">last word to next ⇢</button><button data-m="pull-prev" title="Pull the previous slide's last word into this one">⇢ pull from previous</button><button data-m="pull-next" title="Pull the next slide's first word into this one">⇠ pull from next</button></div>
  </details>
  <div class="frow"><label>Insert as</label><div class="seg" id="a-one"><button data-v="one">One caption</button><button data-v="word">Word by word</button></div></div>
  <div class="frow"><label>First track</label><input type="number" id="a-track" class="num" min="1" max="20" title="First video track: word 1 uses this track, word 2 the next, and so on (up to V8)."><span class="grow"></span></div>
  <div class="progress" id="a-prog" hidden><div class="bar"><i id="a-bar"></i></div><span id="a-pt"></span><button class="btn" id="a-cancel">Cancel</button></div>
  <button class="btn wide outline" id="a-update">Update caption</button>
  <button class="primary" id="a-place">Create captions</button>`;
  const stage = Preview.make('au');
  $('#a-stage-slot').appendChild(stage);

  const styleObj = () => App.style(A.style);

  // ---------- grouping and models ----------
  function groups() {
    const remove = A.punct === 'remove';
    const cw = WBW.clean(A.words, remove);
    if (!cw.length) return [];
    const fps = (App.status && App.status.fps) || 30;
    let counts;
    if (A.one === 'word') counts = cw.map(() => 1);
    else if (A.man && A.man.reduce((x, y) => x + y, 0) === cw.length) counts = A.man.slice();
    else {
      counts = TF.groupCaptions(A.words, { perSlide: A.per, remove, byWord: false, fps }).map((g) => g.words.length);
      if (counts.reduce((x, y) => x + y, 0) !== cw.length) { counts = []; for (let k = 0; k < cw.length; k += A.per) counts.push(Math.min(A.per, cw.length - k)); }
    }
    const out = []; let off = 0;
    counts.forEach((n) => {
      const ws = cw.slice(off, off + n); off += n;
      out.push({ words: ws.map((w) => w.word), text: ws.map((w) => w.word).join(' '), start: ws[0].start, end: ws[ws.length - 1].end, ts: ws.map((w) => w.start), n });
    });
    out.forEach((g, i) => { g.hold = out[i + 1] ? out[i + 1].start : g.end; if (A.edits[i] != null && A.one !== 'word') { g.text = A.edits[i]; g.edited = true; } });
    A.counts = counts;
    return out;
  }
  function models(gs) {
    const st = styleObj();
    const out = [];
    let prevOut = null;
    gs.forEach((g, i) => {
      if (A.one === 'word') { const m = WBW.model(A.style, g.text); if (A.out === 'layout' || A.mode === 'off') m.anim = TF.noAnim(); prevOut = null; out.push(m); return; }
      const r = TF.rng(TF.hash(g.text + '|' + i));
      const words = TF.wordsFrom(g.text, false);
      const blocks = TF.explode(TF.layout(words, A.tpl, st, { look: A.look, scale: A.scale, aspect: App.aspect(), center: [0.5, 0.5] }), App.aspect());
      let anim;
      if (A.mode === 'off' || A.out === 'layout') anim = TF.noAnim();
      else if (A.mode === 'style') anim = TF.clone(st.anim);
      else {
        anim = TF.clone(st.anim);
        const c = A.cust;
        const slide = c.slide && r() * 100 < A.cust.slideP;
        const bounce = c.bounce && r() * 100 < A.cust.bounceP;
        [anim.in, anim.out].forEach((s) => { s.slide = slide || (!bounce && !slide ? false : slide); s.bounce = bounce; });
        if (!slide && !bounce) { anim.in.slide = anim.out.slide = false; }
        if (c.mixed) anim.out.dir = DIRKEYS[Math.floor(r() * 4)];
        anim.in.flicker = r() * 100 < c.flicker; anim.out.flicker = anim.in.flicker;
        anim.in.shake = r() * 100 < c.shake;
        anim.in.blur = r() * 100 < c.blur;
      }
      if (prevOut && anim.in.slide) anim.in.dir = prevOut; // entry follows previous exit
      prevOut = anim.out.slide ? anim.out.dir : null;
      out.push({ styleId: st.id, template: A.tpl, look: A.look, blocks, anim });
    });
    return out;
  }

  // ---------- rendering ----------
  const sample = (st) => ({ styleId: st.id, blocks: TF.layout(['EASY', 'MOTION'], 1, st, { aspect: 16 / 10, scale: 2.6 }), anim: st.anim });
  const thumb = (el, st) => { const t = Preview.make('sm'); t.style.aspectRatio = '16/10'; el.innerHTML = ''; el.appendChild(t); Preview.render(t, sample(st)); };
  function renderStyles() {
    thumb($('#a-thumb'), styleObj()); $('#a-sc-name').textContent = styleObj().name;
    const el = $('#a-styles'); el.innerHTML = '';
    App.styles().forEach((s) => {
      const b = document.createElement('button');
      b.className = 'mcard' + (s.id === A.style ? ' on' : '');
      const th = document.createElement('span'); th.className = 'thumb'; b.appendChild(th);
      const nm = document.createElement('span'); nm.textContent = s.name; b.appendChild(nm);
      b.addEventListener('click', () => { A.style = s.id; el.hidden = true; renderStyles(); refresh(); });
      el.appendChild(b); thumb(th, s);
    });
  }
  $('#a-stylecard').addEventListener('click', () => { $('#a-styles').hidden = !$('#a-styles').hidden; });
  function refresh() {
    const gs = groups(), ms = models(gs);
    if (A.cur >= gs.length) A.cur = Math.max(0, gs.length - 1);
    if (A.anPlay) { A.anPlay.cancel(); A.anPlay = null; }
    App.setAspect(stage);
    if (!gs.length) {
      stage.innerHTML = '<div class="empty-in">No captions loaded</div>';
      $('#a-i').textContent = '0 / 0'; $('#a-tc').textContent = ''; $('#a-mini').innerHTML = ''; $('#a-edit').value = ''; $('#a-prev').innerHTML = ''; $('#a-next').innerHTML = ''; $('#a-tcnow').textContent = '';
      $('#a-place').disabled = true; $('#a-update').disabled = true; return;
    }
    $('#a-place').disabled = A.placing; $('#a-update').disabled = A.placing;
    $$('#a-moves button').forEach((b) => { b.disabled = A.one === 'word'; });
    const g = gs[A.cur];
    Preview.render(stage, ms[A.cur]);
    $('#a-i').textContent = `${A.cur + 1} / ${gs.length}`;
    $('#a-tc').textContent = `${App.tc(g.start)} — ${App.tc(g.hold)}`;
    $('#a-tcnow').textContent = App.tc(g.start);
    [['#a-prev', A.cur - 1], ['#a-next', A.cur + 1]].forEach(([id, k]) => {
      const el = $(id); el.innerHTML = '';
      if (k < 0 || k >= gs.length) return;
      const t = Preview.make('sm'); el.appendChild(t); Preview.render(t, ms[k]);
    });
    $('#a-dot').hidden = !g.edited;
    if (document.activeElement !== $('#a-edit')) $('#a-edit').value = g.text;
    $('#a-edit').disabled = A.one === 'word';
    const total = gs[gs.length - 1].hold - gs[0].start || 1;
    $('#a-mini').innerHTML = gs.map((s, i) => `<i data-i="${i}" class="${i === A.cur ? 'on' : ''}${s.edited ? ' ed' : ''}" style="left:${((s.start - gs[0].start) / total) * 100}%;width:${Math.max(0.6, ((s.hold - s.start) / total) * 100)}%" title="${esc(s.text)}"></i>`).join('');
  }

  // ---------- loading ----------
  function setWords(ws, src) {
    A.words = ws; A.edits = {}; A.man = null; A.cur = 0; A.source = src;
    $('#a-info').innerHTML = ws.length ? `<b>${ws.length} words</b> <span class="mute">· ${esc(src)}</span>` : '<span class="mute">No words found.</span>';
    refresh();
  }
  async function read() {
    const r = await App.call('readCaptions', { useInOut: $('#a-io').checked });
    if (!r.ok) return;
    if (!r.hasSubtitles) { setWords([], ''); $('#a-info').innerHTML = '<span class="mute">No subtitle track. Press Generate from audio, create subtitles in Resolve, or paste text below.</span>'; return; }
    setWords(r.words, r.inOut && $('#a-io').checked ? 'from subtitles in In/Out' : 'from subtitle track');
    if (!r.words.length) $('#a-info').innerHTML = '<span class="mute">Subtitle track found but nothing inside In/Out.</span>';
  }
  $('#a-read').addEventListener('click', read);
  $('#a-gen').addEventListener('click', async () => {
    App.msg('Generating subtitles from audio… this can take a while.');
    const r = await App.call('generateCaptions');
    if (r.ok) { App.msg('Subtitles created.', 'ok'); read(); }
  });
  $('#a-usepaste').addEventListener('click', async () => {
    const txt = $('#a-paste').value.trim();
    if (!txt) return App.msg('Paste some text first.', 'err');
    const st = App.status || {};
    const ws = txt.split(/\s+/);
    const fps = st.fps || 30;
    let a = st.playhead || 0, b = a + Math.round(fps * 10);
    if (st.inOut && $('#a-io').checked) { a = st.inOut.in; b = st.inOut.out; }
    const per = (b - a) / ws.length;
    setWords(ws.map((w, i) => ({ word: w, start: Math.round(a + i * per), end: Math.round(a + (i + 1) * per) })), 'pasted text');
  });

  // ---------- controls ----------
  slider($('#a-per'), $('#a-per-v'), (v) => 'up to ' + v + (v === 1 ? ' word' : ' words'), (v) => { A.per = v; A.edits = {}; A.man = null; refresh(); });
  seg($('#a-punct'), () => A.punct, (v) => { A.punct = v; A.man = null; A.edits = {}; refresh(); });
  seg($('#a-out'), () => A.out, (v) => { A.out = v; refresh(); });
  function move(kind) {
    groups(); const c = (A.counts || []).slice(), i = A.cur; if (A.one === 'word' || !c.length) return;
    if (kind === 'first-back' && i > 0 && c[i] > 1) { c[i - 1]++; c[i]--; }
    else if (kind === 'last-fwd' && i < c.length - 1 && c[i] > 1) { c[i + 1]++; c[i]--; }
    else if (kind === 'pull-prev' && i > 0 && c[i - 1] > 1) { c[i - 1]--; c[i]++; }
    else if (kind === 'pull-next' && i < c.length - 1 && c[i + 1] > 1) { c[i + 1]--; c[i]++; }
    else return App.msg('That move would leave a slide empty.', 'err');
    A.man = c; A.edits = {}; refresh();
  }
  $$('#a-moves button').forEach((b) => b.addEventListener('click', () => move(b.dataset.m)));
  const paintMode = seg($('#a-mode'), () => A.mode, (v) => { A.mode = v; $('#a-cust').hidden = v !== 'custom'; refresh(); });
  seg($('#a-tpl'), () => A.tpl, (v) => { A.tpl = +v; refresh(); });
  seg($('#a-look'), () => A.look, (v) => { A.look = v; refresh(); });
  slider($('#a-size'), $('#a-size-v'), (v) => Math.round(v) + '%', (v) => { A.scale = v / 100; refresh(); });
  seg($('#c-dirs'), () => (A.cust.mixed ? 'mixed' : 'style'), (v) => { A.cust.mixed = v === 'mixed'; refresh(); });
  A.cust.slideP = 70; A.cust.bounceP = 30;
  slider($('#c-slide-r'), $('#c-slide-v'), (v) => Math.round(v) + '%', (v) => { A.cust.slideP = v; refresh(); }); $('#c-slide-r').value = 70;
  slider($('#c-bounce-r'), $('#c-bounce-v'), (v) => Math.round(v) + '%', (v) => { A.cust.bounceP = v; refresh(); }); $('#c-bounce-r').value = 30;
  $('#c-slide').addEventListener('change', (e) => { A.cust.slide = e.target.checked ? 1 : 0; refresh(); });
  $('#c-bounce').addEventListener('change', (e) => { A.cust.bounce = e.target.checked ? 1 : 0; refresh(); });
  A.cust.slide = 1; A.cust.bounce = 0;
  [['flicker'], ['shake'], ['blur']].forEach(([k]) => slider($('#c-' + k), $('#c-' + k + '-v'), (v) => Math.round(v) + '%', (v) => { A.cust[k] = v; refresh(); }));
  $('#c-slide-r').dispatchEvent(new Event('input')); $('#c-bounce-r').dispatchEvent(new Event('input'));

  $('#a-prev').addEventListener('click', () => { A.cur = Math.max(0, A.cur - 1); refresh(); });
  $('#a-next').addEventListener('click', () => { A.cur++; refresh(); });
  $('#a-mini').addEventListener('click', (e) => { const i = e.target.dataset.i; if (i != null) { A.cur = +i; refresh(); } });
  $('#a-play').addEventListener('click', () => {
    const gs = groups(); if (!gs.length) return;
    const g = $('.grp', stage); if (g) A.anPlay = Preview.play(g, models(gs)[A.cur]);
  });
  $('#a-edit').addEventListener('input', (e) => { A.edits[A.cur] = e.target.value; const gs = groups(), ms = models(gs); Preview.render(stage, ms[A.cur]); $('#a-dot').hidden = false; });
  $('#a-track').value = A.track;
  $('#a-track').addEventListener('change', (e) => { A.track = Math.max(1, parseInt(e.target.value, 10) || 2); });
  seg($('#a-one'), () => A.one, (v) => { A.one = v; A.cur = 0; refresh(); });

  // ---------- placing ----------
  App.on('progress', (d) => { if (!A.placing) return; $('#a-bar').style.width = (d.i / d.n) * 100 + '%'; $('#a-pt').textContent = `Placing captions… ${d.i}/${d.n}`; });
  $('#a-cancel').addEventListener('click', () => App.call('cancel'));
  $('#a-place').addEventListener('click', async () => {
    const gs = groups(); if (!gs.length) return;
    const ms = models(gs);
    let items = [];
    gs.forEach((g, i) => { items = items.concat(WL.items(ms[i], WL.starts(g, ms[i].blocks.length), Math.max(g.hold, g.end), A.track)); });
    A.placing = true; $('#a-place').disabled = true; $('#a-prog').hidden = false; $('#a-bar').style.width = '0%'; $('#a-pt').textContent = `Placing words… 0/${items.length}`;
    const r = await WL.place(items);
    A.placing = false; $('#a-place').disabled = false; $('#a-prog').hidden = true;
    if (r.ok) App.msg(`Created ${r.done - r.failed}/${items.length} word layers${r.cancelled ? ' (cancelled)' : ''}${r.failed ? `, ${r.failed} failed (see Log)` : ''}.${r.warning ? ' ' + r.warning : ''}`, r.failed ? 'err' : 'ok');
  });
  $('#a-update').addEventListener('click', async () => {
    const gs = groups(); if (!gs.length) return;
    const ms = models(gs), g = gs[A.cur], m = ms[A.cur];
    const starts = WL.starts(g, m.blocks.length);
    const its = WL.items(m, starts, Math.max(g.hold, g.end), A.track);
    let found = 0;
    for (const it of its) { const r = await App.call('updateAt', { start: it.start, track: it.track, model: it.model }); if (r.ok && r.found) found++; }
    App.msg(found ? `Updated caption ${A.cur + 1}.` : 'No TitleFlow title found at this caption yet. Use Create captions first.', found ? 'ok' : 'err');
  });

  A.style = TF.STYLES[1].id;
  renderStyles(); refresh();
  App.on('status', () => App.setAspect(stage));
  return { A, read, refresh };
})();
