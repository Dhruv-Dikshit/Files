// Renders a title model into a "stage" element and plays its animation with the same
// maths (TF.sampleChannels) that the Fusion expressions use.
const Preview = {
  rgb(c) { return `rgb(${c.map((v) => Math.round(v * 255)).join(',')})`; },
  weight(fs) { return { Light: 300, Regular: 400, Medium: 500, Bold: 700, ExtraBold: 800, Black: 900 }[fs] || 700; },

  make(cls) {
    const s = document.createElement('div');
    s.className = 'stage ' + (cls || '');
    App.setAspect(s);
    return s;
  },

  // returns the group element (the thing that animates)
  render(stage, model) {
    stage.innerHTML = '';
    const grp = document.createElement('div');
    grp.className = 'grp';
    const bb = TF.bbox(model.blocks, App.aspect());
    grp.style.transformOrigin = `${bb.cx * 100}% ${(1 - bb.cy) * 100}%`;
    model.blocks.forEach((b, i) => {
      const d = document.createElement('div');
      d.className = 'blk';
      d.dataset.i = i;
      d.textContent = b.text;
      const col = Preview.rgb(b.color);
      const fx = b.fx || {};
      const shadows = [];
      if (b.glow) { const k = b.glowS == null ? 1 : b.glowS; shadows.push(`0 0 ${0.22 * k}em ${col}`, `0 0 ${0.5 * k}em ${col.replace('rgb', 'rgba').replace(')', ',.55)')}`); }
      if (fx.shadow) shadows.push(`0 .05em ${(fx.shadow.blur == null ? 0.25 : fx.shadow.blur) * 0.5}em rgba(0,0,0,${fx.shadow.opacity == null ? 0.6 : fx.shadow.opacity})`);
      let css = `left:${b.x * 100}%;top:${(1 - b.y) * 100}%;font-size:${b.size * 95}cqh;color:${col};` +
        `font-family:"${b.font}",Montserrat,"Helvetica Neue",Arial,sans-serif;font-weight:${Preview.weight(b.fontStyle)};`;
      if (shadows.length) css += `text-shadow:${shadows.join(',')};`;
      if (b.tracking != null && b.tracking !== 1) css += `letter-spacing:${(b.tracking - 1) * 0.3}em;`;
      if (b.opacity != null && b.opacity < 1) css += `opacity:${b.opacity};`;
      if (fx.outline) css += `-webkit-text-stroke:${(fx.outline.w == null ? 0.02 : fx.outline.w) * 30}cqh ${fx.outline.color ? Preview.rgb(fx.outline.color) : '#000'};paint-order:stroke fill;`;
      else if (fx.border) css += `-webkit-text-stroke:${(fx.border.w == null ? 0.02 : fx.border.w) * 30}cqh #000;paint-order:stroke fill;`;
      if (fx.gradient) css += `background:linear-gradient(${fx.gradient.angle == null ? 90 : fx.gradient.angle}deg,${Preview.rgb(fx.gradient.c1 || [1, 1, 1])},${Preview.rgb(fx.gradient.c2 || [0.3, 0.3, 0.3])});-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;`;
      if (fx.blur && fx.blur.amt) css += `filter:blur(${fx.blur.amt * 0.05}em);`;
      if (b.case === 'upper') d.textContent = b.text.toUpperCase(); else if (b.case === 'lower') d.textContent = b.text.toLowerCase();
      d.style.cssText = css;
      grp.appendChild(d);
    });
    stage.appendChild(grp);
    return grp;
  },

  play(grp, model, opts) {
    opts = opts || {};
    const a = model.anim;
    const D = Math.max(12, Math.round(a.in.frames + 20 + a.out.frames));
    const seed = TF.hash(model.blocks.map((b) => b.text).join('|'));
    const ch = TF.sampleChannels(a, D, seed);
    const kf = ch.map((c, f) => ({
      offset: f / (D - 1),
      transform: `translate(${c.x * 100}cqw, ${-c.y * 100}cqh) scale(${c.s}) rotate(${c.a}deg)`,
      opacity: Math.max(0, Math.min(1, c.b)),
      filter: c.bl > 0.05 ? `blur(${(c.bl / 1080) * 100}cqh)` : 'none',
    }));
    return grp.animate(kf, { duration: (D / 30) * 1000, iterations: opts.loop === false ? 1 : Infinity, endDelay: 350 });
  },

  // hover helper: plays on mouseenter, cancels on mouseleave
  hover(el, stage, getModel) {
    let an = null;
    el.addEventListener('mouseenter', () => { const m = getModel(); const g = $('.grp', stage); if (g && m) an = Preview.play(g, m); });
    el.addEventListener('mouseleave', () => { if (an) an.cancel(); an = null; });
  },
};
