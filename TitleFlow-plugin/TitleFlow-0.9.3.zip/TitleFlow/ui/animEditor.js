// IN / OUT animation controls: Slide|Bounce, direction pads, centre effects, per-side chips,
// and a Distance/Frames popover. Used by the Workspace tab and the Titles editor.
const AnimEditor = {
  ARROWS: { left: '◀', right: '▶', up: '▲', down: '▼', none: '•' },

  mount(root, api) {
    const A = AnimEditor.ARROWS;
    root.classList.add('ae');
    const pad = (side) => ['', 'up', '', 'left', 'none', 'right', '', 'down', '']
      .map((d) => (d ? `<button data-side="${side}" data-dir="${d}" title="${d}">${A[d]}</button>` : '<i></i>')).join('');
    const sideHTML = (side) => `
      <div class="ae-side" data-s="${side}">
        <div class="seg"><button data-side="${side}" data-act="slide">Slide</button><button data-side="${side}" data-act="bounce">Bounce</button></div>
        <div class="pad">${pad(side)}</div>
        <div class="chips">
          <button data-side="${side}" data-chip="flicker">Flicker</button>
          ${side === 'in' ? `<button data-side="${side}" data-chip="shake">Shake</button>` : ''}
          <button data-side="${side}" data-chip="blur">Blur</button>
        </div>
      </div>`;
    const tile = (fx, label) => `<button class="tile" data-fx="${fx}">${ICONS[fx]}<span>${label}</span></button>`;
    const more = (side) => `<div class="ae-more-side"><span class="mute">${side.toUpperCase()}</span>
        <select class="preset" data-side="${side}" title="Motion preset"><option value="">Preset…</option>${TF.PRESETS.map((p) => `<option value="${p.id}">${p.name}</option>`).join('')}</select>
        <select class="ease" data-side="${side}" title="Easing curve">${Object.keys(TF.EASE_NAMES).map((k) => `<option value="${k}">${TF.EASE_NAMES[k]}</option>`).join('')}</select></div>`;
    root.innerHTML = `
      <div class="ae-grid">
        ${sideHTML('in')}
        <div class="ae-mid">${tile('shake', 'Shake')}${tile('jitter', 'Jitter')}${tile('scribble', 'Scribble')}${tile('mblur', 'M. Blur')}</div>
        ${sideHTML('out')}
      </div>
      <button class="ae-moretoggle" title="Presets, easing and extra effects">${ICONS.more}</button>
      <div class="ae-more" hidden>
        ${more('in')}${more('out')}
        <div class="chips ae-extra"><button data-fx="glow">Glow</button><button data-fx="blur">Blur</button><button data-fx="crt">CRT</button></div>
      </div>
      <div class="ae-pop" hidden>
        <div class="ae-pop-h"><b></b><button class="x">×</button></div>
        <div class="row"><label>Distance</label><input type="range" class="d" min="0.005" max="0.3" step="0.005"><span class="dv"></span></div>
        <div class="row"><label>Frames</label><input type="range" class="f" min="2" max="40" step="1"><span class="fv"></span></div>
      </div>`;
    $('.ae-moretoggle', root).addEventListener('click', (e) => { e.stopPropagation(); const m = $('.ae-more', root); m.hidden = !m.hidden; e.currentTarget.classList.toggle('on', !m.hidden); });
    const pop = $('.ae-pop', root);
    let popSide = null;

    const get = () => api.get();
    const change = (fn) => { const a = get(); if (!a) return; fn(a); api.set(a); refresh(); };

    function refresh() {
      const a = get();
      root.classList.toggle('off', !a);
      if (!a) return;
      ['in', 'out'].forEach((s) => {
        const v = a[s];
        $$(`[data-side="${s}"][data-act]`, root).forEach((b) => b.classList.toggle('on', !!v[b.dataset.act]));
        $$(`[data-side="${s}"][data-chip]`, root).forEach((b) => b.classList.toggle('on', !!v[b.dataset.chip]));
        $$(`[data-side="${s}"][data-dir]`, root).forEach((b) => b.classList.toggle('on', b.dataset.dir === v.dir && v.slide));
      });
      ['in', 'out'].forEach((sd) => {
        const pr = $(`select.preset[data-side="${sd}"]`, root), ez = $(`select.ease[data-side="${sd}"]`, root);
        if (pr) pr.value = a[sd].preset || ''; if (ez) ez.value = a[sd].ease || 'cubic';
      });
      $$('[data-fx]', root).forEach((b) => b.classList.toggle('on', !!(a.fx || {})[b.dataset.fx]));
      if (popSide) fillPop();
    }
    function fillPop() {
      const v = get()[popSide];
      $('b', pop).textContent = popSide.toUpperCase();
      $('.d', pop).value = v.dist; $('.dv', pop).textContent = v.dist.toFixed(3);
      $('.f', pop).value = v.frames; $('.fv', pop).textContent = String(v.frames);
    }

    root.addEventListener('change', (e) => {
      const t = e.target; if (!(t instanceof HTMLSelectElement) || !get()) return;
      const sd = t.dataset.side;
      if (t.classList.contains('preset')) { if (t.value) change((a) => { TF.applyPreset(a[sd], t.value); }); }
      else if (t.classList.contains('ease')) change((a) => { a[sd].ease = t.value; a[sd].preset = a[sd].preset; });
    });
    root.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b || b.classList.contains('ae-moretoggle') || !get()) return;
      if (b.classList.contains('x')) { pop.hidden = true; popSide = null; return; }
      const side = b.dataset.side;
      if (b.dataset.dir) {
        change((a) => { a[side].dir = b.dataset.dir; a[side].slide = true; });
        popSide = side; fillPop(); pop.hidden = false;
      } else if (b.dataset.act) change((a) => { a[side][b.dataset.act] = !a[side][b.dataset.act]; });
      else if (b.dataset.chip) change((a) => { a[side][b.dataset.chip] = !a[side][b.dataset.chip]; });
      else if (b.dataset.fx) change((a) => { a.fx = a.fx || {}; a.fx[b.dataset.fx] = !a.fx[b.dataset.fx]; });
    });
    $('.d', pop).addEventListener('input', (e) => change((a) => { a[popSide].dist = parseFloat(e.target.value); }));
    $('.f', pop).addEventListener('input', (e) => change((a) => { a[popSide].frames = parseInt(e.target.value, 10); }));

    refresh();
    return { refresh };
  },
};
