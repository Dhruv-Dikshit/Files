# TitleFlow 0.9.3 – install guide (read it, don't run it)

Needs DaVinci Resolve **Studio**, and Preferences > System > General > "External scripting using" set to **Local**.

1. Find the example plugin's native file:
   `/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Workflow Integrations/Examples/SamplePlugin/WorkflowIntegration.node`
2. Copy this whole TitleFlow folder into Resolve's plugin folder (Terminal):
   `sudo mkdir -p "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins/TitleFlow"`
   `sudo cp -R ~/Downloads/TitleFlow/* "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins/TitleFlow/"`
3. Copy `WorkflowIntegration.node` from step 1 into that TitleFlow folder too.
4. Restart Resolve > Workspace > Workflow Integrations > TitleFlow.

## One-time Resolve setting
Set **Preferences > User > Editing > Standard Generator Duration** to **7 seconds**. TitleFlow can cut a title shorter (1-7 s) but cannot stretch it past Resolve's default Text+ length.

## How captions are built (0.5.1)
Every spoken word is its own Text+ layer. Word 1 of a caption goes on the first track you choose (default V2), word 2 on the next track, and so on. Each layer starts when the word is spoken and ends when the caption ends, so a caption builds up word by word and leaves together. Templates 1/2/3 only change where the words sit on screen. Leave 3-5 free video tracks above your footage.

## What is in 0.5
- **Workspace**: click a word, Shift-click several, or drag a box over the canvas to select a whole caption (Cmd+A = all). Move, scale (corner handles), align, duplicate, copy/paste style, delete and arrow-key nudge all act on the selection. Aa / colour opens the full text style card (font, weight, case, size, tracking, opacity, gradient/borders/outline/shadow/glow/blur). Zoom, collapsible animation panel, and a film button that puts the current video frame behind the canvas (park the playhead off a title for a clean frame).
- **Titles**: hover = animated preview, In/Out words auto-filled, "titles with N blocks" filter, Insert as One caption or Word by word, Add from timeline opens the Add to gallery dialog.
- **Auto**: Animated titles or Layouts only, move words between slides, Create captions, Update caption (re-applies the current slide).
- **Convert Captions** (header): one animated title per subtitle word, with progress and Cancel.
- **"..." menu**: report a bug (opens the log), check for updates, Render Cache tip.
- For accurate word timing: in Resolve use Timeline > Create Subtitles from Audio with Maximum characters per line = 1, Lines = Single, Gap = 0 (Generate from audio tries to do this for you).
- Known gaps: outline/borders/gradient/shadow/blur show in the preview but are not yet written to Resolve; per-word styling and drag-between-lines in the Titles editor are not built yet.

## Reporting bugs
Open **Log ▴** at the bottom, press **Copy log**, paste it with a short note of what worked / didn't, per tab.
Files written: `~/TitleFlow_log.txt`, `~/TitleFlow_last.comp`.

## v0.7 notes
- 21 motion presets, 7 easing curves (Linear, Ease in, Ease out, Ease in-out, Strong ease, Expo, Overshoot) per IN/OUT side.
- Continuous effects: Shake, Jitter, Scribble, Motion blur, Glow, Blur, CRT (flicker + jitter, no scanlines).
- Outline, border, shadow, blur, glow, opacity, case and tracking are written into the Resolve title.
- Titles tab: new "Lines" editor. Drag word chips between lines, click the BIG/small tag to swap size, click a word to set its colour/size, Shift-click a word to make it the main word.
- Still not built: Inspector controls on inserted titles (macro wrapper), typewriter, gradient inside Resolve, one-word neon style.
- Pre-Animate presets (Fast / normal / V2) added from your .drfx packs: full-screen slide, motion blur, their frame timings (15/21/45). Pick the direction on the pad: in and out directions chain like Left Left, Left Right.
- NEON style added (cyan glow, pulsing glow, flicker in/out) based on your neon node tree. Approximation: it uses TitleFlow's own glow, not your exact Glow + SoftGlow nodes.

## v0.8
- Canvas is always 1080x1920 (9:16 reel only), whatever the timeline size.
- Restyled to match the reference: SVG icons, orange-filled selected buttons, grouped tabs, floating canvas tools.

## v0.9.1
- One caption = one Text+ clip on one track (Resolve can only insert on the timeline's destination track). Each word still pops in when it is spoken.
- Point the timeline destination (the red V patch on the Edit page) at the track set in TitleFlow (V2 by default).
- Inserted titles are wrapped in a "TitleFlow" macro, so the Inspector shows Text, Font, Size, Color, Tracking and Position for every word.
- Works with Resolve 21's in-place comp import.

## v0.9.2
- Fixed "No frame available for MediaOut1": MediaOut is wired to the macro output.
- The comp sets the TitleFlow macro as its active tool so the Edit page Inspector shows its controls.
- Fixed a crash when finishing an inline text edit on the canvas.

## v0.9.3
- Uses Resolve's own Text+ title: TitleFlow no longer replaces it with its own node tree. It exports the clip's Text+ comp, changes only the Text+ settings (text, font, colour, size, position, outline, shadow, animation expressions) and imports it back, then checks the change landed (log: "verify: Text+ settings applied").
- The Inspector shows the normal Text+ controls.
- Not available in this mode yet: glow, scribble and CRT (they need extra nodes).
