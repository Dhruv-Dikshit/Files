Agent Pals - Animated AI Agent Lottie Pack
==========================================

Thank you for purchasing Agent Pals!

Agent Pals is a family of 18 cute bot characters made for AI products.
Each bot has 13 looping states that show what an agent is doing right now:
reading, thinking, working, done and more. Use them in chat UIs, agent
dashboards, onboarding, tab bars, empty states or loading screens.


WHAT'S INSIDE
-------------
- 234 Lottie animations (.json): 18 bots x 13 states
- Editable Figma source: 35 components, 38 colour variables,
  234 animated frames
- 200 x 200 canvas, transparent background, same framing for every file
- Seamless loops: 2.4 s (Working: 3.2 s)
- Pure vector shapes, crisp at any size


THE BOTS
--------
Flower, Drop, Triangle, Circle, Pill, Clover, Scallop, Star, Heart,
Square, Hexagon, Arch, Ghost, Oval, Briefcase, Flame, Cloud, Cat


THE STATES
----------
Idle        gentle bob and blink (default state)
Working     orbit ring with a sparkle, star and dot circling the bot
Typing      tapping on a small keyboard
Thinking    three thinking dots
Reading     reading an open book
Writing     writing lines on a page with a pencil
Designing   drawing on an artboard with a cursor
Coding      code window filling with lines, </> badge
Searching   looking through a magnifier
Listening   headphones on, sound bars
Sleeping    eyes closed, floating Z
Done        happy eyes with sparkles
Error       squeezed eyes with a sweat drop

Typical agent flow: Reading > Thinking > Working > Done.


FILE STRUCTURE
--------------
Agent Pals/
  Lottie/
    Flower/
      Flower - Idle.json
      Flower - Working.json
      ...
    Drop/
    ...
    Cat/
  Agent Pals.fig      (Figma source)
  readme.txt

One folder per bot, one file per state: "<Bot> - <State>.json".


FIGMA SOURCE
------------
The Figma file has one page, "Bots", with two sections:

Bot Kit      35 master components
             - Body/* (18): one per bot, coloured by variables
             - Eye/* (5): Open, Closed, Happy, SquintL, SquintR
             - Prop/* (12): Sparkle, Orbit, Dot, Book, Z, Keys, Sweat,
               Pencil, Magnifier, Cursor, CodeBadge, EarCup
Bot Motion   234 animated frames named "<Bot> / <State>" (200 x 200),
             built with Figma Motion keyframes

Colours live in the "Bot Colors" variable collection (38 variables):
- bot/<name>/deep and bot/<name>/bright: the two colours of each bot
- bot/eye: eye colour
- bot/stage: dark colour used inside some props

Font: Inter (free Google Font), used only for the small "z" and "</>" props.


QUICK START
-----------
1. Pick a bot and a state, for example "Flower - Thinking.json".
2. Add it to your project with any Lottie player (see below).
3. Set it to loop and autoplay.
4. Swap the file when your agent's state changes (Reading > Thinking > Working > Done).


WHERE TO USE
------------
- Web: lottie-web, the LottieFiles / dotLottie player, Webflow, Framer, Wix
- iOS: lottie-ios
- Android: lottie-android
- React Native, Flutter: their official Lottie packages
- Figma: open the source file and play any frame with Figma Motion

Tip: every bot shares the same canvas, size and position, so you can switch
between states (or between bots) without anything jumping on screen.


HOW TO CUSTOMIZE
----------------
- Size: Lottie is vector, so scale the player to any size you need.
- Speed: change the playback speed in your player (for example 0.8x for a calmer feel).
- Colours (Figma): edit bot/<name>/deep and bot/<name>/bright in "Bot Colors".
  Every component, frame and state of that bot updates at once.
- Motion (Figma): open any "<Bot> / <State>" frame and edit its keyframes.
- New Lottie files: select a frame in Bot Motion and export it as Lottie.
- Colours (JSON only): open a file in a Lottie editor (for example the
  LottieFiles editor) and change the body fill colours.


GOOD TO KNOW
------------
- Files have a transparent background and work on light or dark surfaces.
- Bots do not include text, so they work in any language.
- Shading is built from vector layers (no shadow or blur effects), so the
  bots look the same in every Lottie player.
- Refer to the UI8 license for usage terms.


SUPPORT
-------
Questions or feedback? thesomehowstudio@gmail.com

Thanks again for your support, and happy animating!
